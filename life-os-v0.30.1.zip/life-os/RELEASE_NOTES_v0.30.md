# LIFE OS v0.30

## Foco: testes de execução de autenticação

- Adicionados testes unitários para `AuthGuard` cobrindo cabeçalhos ausentes/inválidos, tokens malformados, expirados, assinatura incorreta, claims verificadas e segredo ausente.
- Adicionados testes unitários para `AuthService` cobrindo registo, normalização de email, hash de palavra-passe, duplicação de email, login inválido e emissão de JWT.
- Declarado `@types/node` como dependência de desenvolvimento da workspace para não depender de uma instalação transitiva de tipos Node.
- Corrigida a normalização de email: espaços exteriores são removidos antes de converter para minúsculas em registo e login.
- Versões móvel e Expo atualizadas para `0.30.0`.

## Validação executada

- `npm run test:contracts`: passou — 17 testes estáticos, 9 regras de chaves estrangeiras e verificadores de segurança/lançamento.
- Sintaxe TypeScript: 54 ficheiros verificados, sem diagnósticos de sintaxe.
- Testes de scoring: 5 passaram após compilação com os tipos Node disponíveis no ambiente.
- Testes de localização móvel: 3 passaram após transpilar os módulos i18n para uma pasta temporária.
- Integridade do ZIP: validada com `unzip -t`.

## Limitações

A instalação de dependências (`npm install`) excedeu o limite de execução deste ambiente. Assim, os testes unitários que carregam NestJS, bcrypt, JWT e Prisma, o typecheck semântico, o teste PostgreSQL real e os builds Expo não puderam ser executados aqui. Devem correr no CI configurado antes de considerar a versão validada para produção.
