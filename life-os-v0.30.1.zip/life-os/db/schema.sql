create extension if not exists pgcrypto;

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  name text,
  timezone text not null default 'Europe/Lisbon',
  language text not null default 'pt-PT',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);
create table if not exists life_areas (
  id text primary key,
  name text not null,
  active boolean not null default true
);
insert into life_areas(id,name) values
('RELATIONSHIPS','Relacionamentos e Amor'),('FAMILY_FRIENDS','Família e Amizades'),('EMOTIONAL_WELLBEING','Bem-estar Emocional'),('HEALTH_ENERGY','Saúde e Energia'),('FINANCES','Finanças e Segurança'),('CAREER','Carreira e Realização'),('AUTONOMY','Autonomia e Liberdade'),('PURPOSE','Propósito e Sentido'),('PLEASURE','Prazer e Experiências'),('GROWTH','Crescimento Pessoal')
on conflict(id) do nothing;
create table if not exists life_area_assessments (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references users(id) on delete cascade, area_id text not null references life_areas(id), satisfaction smallint not null check(satisfaction between 0 and 10), importance smallint not null check(importance between 0 and 10), motivation smallint not null check(motivation between 0 and 10), capacity smallint not null check(capacity between 0 and 10), created_at timestamptz not null default now()
);
create index if not exists idx_assessment_user_area on life_area_assessments(user_id,area_id,created_at desc);
create table if not exists goals (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references users(id) on delete cascade, title text not null, description text, goal_type text not null check(goal_type in ('OUTCOME','PROCESS','NEED','VALUE')), life_area_id text references life_areas(id), motivation smallint check(motivation between 0 and 10), importance smallint check(importance between 0 and 10), deadline date, status text not null default 'ACTIVE', created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists actions (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references users(id) on delete cascade, goal_id uuid references goals(id) on delete set null, life_area_id text references life_areas(id), title text not null, description text, estimated_minutes integer, effort smallint check(effort between 0 and 10), complexity smallint check(complexity between 0 and 10), expected_impact smallint check(expected_impact between 0 and 10), confidence smallint check(confidence between 0 and 10), priority_score numeric, scheduled_date date, status text not null default 'PENDING', created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists checkins (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references users(id) on delete cascade, mood smallint check(mood between 0 and 10), energy smallint check(energy between 0 and 10), stress smallint check(stress between 0 and 10), important_event text, notes text, created_at timestamptz not null default now()
);
create table if not exists ai_memories (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references users(id) on delete cascade, category text not null, content text not null, confidence numeric, source text, user_confirmed boolean not null default false, active boolean not null default true, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists insights (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references users(id) on delete cascade, type text not null, title text not null, description text not null, confidence numeric, evidence jsonb, dismissed boolean not null default false, created_at timestamptz not null default now()
);

-- v0.2 additions for authenticated users and action learning
alter table users add column if not exists password_hash text;
alter table users alter column password_hash set default '';
create table if not exists action_results (
 id uuid primary key default gen_random_uuid(),
 action_id uuid not null references actions(id) on delete cascade,
 user_id uuid not null references users(id) on delete cascade,
 completion text not null check(completion in ('COMPLETED','PARTIAL','SKIPPED')),
 difficulty smallint check(difficulty between 0 and 10),
 benefit smallint check(benefit between 0 and 10),
 mood_before smallint check(mood_before between 0 and 10),
 mood_after smallint check(mood_after between 0 and 10),
 energy_before smallint check(energy_before between 0 and 10),
 energy_after smallint check(energy_after between 0 and 10),
 notes text,
 created_at timestamptz not null default now()
);
create index if not exists idx_action_results_user_created on action_results(user_id,created_at desc);
