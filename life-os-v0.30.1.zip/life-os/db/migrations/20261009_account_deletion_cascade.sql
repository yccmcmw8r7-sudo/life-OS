-- LIFE OS v0.24: align existing PostgreSQL foreign keys with Prisma's account deletion policy.
-- Run against a backup or disposable database first. This migration intentionally makes
-- permanent account deletion cascade through all user-owned data.

-- Run as one transaction so partial constraint updates are never committed.
BEGIN;

ALTER TABLE life_area_assessments DROP CONSTRAINT IF EXISTS life_area_assessments_user_id_fkey;
ALTER TABLE life_area_assessments ADD CONSTRAINT life_area_assessments_user_id_fkey
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

ALTER TABLE goals DROP CONSTRAINT IF EXISTS goals_user_id_fkey;
ALTER TABLE goals ADD CONSTRAINT goals_user_id_fkey
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

ALTER TABLE actions DROP CONSTRAINT IF EXISTS actions_user_id_fkey;
ALTER TABLE actions ADD CONSTRAINT actions_user_id_fkey
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;
ALTER TABLE actions DROP CONSTRAINT IF EXISTS actions_goal_id_fkey;
ALTER TABLE actions ADD CONSTRAINT actions_goal_id_fkey
  FOREIGN KEY (goal_id) REFERENCES goals(id) ON DELETE SET NULL;

ALTER TABLE checkins DROP CONSTRAINT IF EXISTS checkins_user_id_fkey;
ALTER TABLE checkins ADD CONSTRAINT checkins_user_id_fkey
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

ALTER TABLE ai_memories DROP CONSTRAINT IF EXISTS ai_memories_user_id_fkey;
ALTER TABLE ai_memories ADD CONSTRAINT ai_memories_user_id_fkey
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

ALTER TABLE insights DROP CONSTRAINT IF EXISTS insights_user_id_fkey;
ALTER TABLE insights ADD CONSTRAINT insights_user_id_fkey
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

ALTER TABLE action_results DROP CONSTRAINT IF EXISTS action_results_action_id_fkey;
ALTER TABLE action_results ADD CONSTRAINT action_results_action_id_fkey
  FOREIGN KEY (action_id) REFERENCES actions(id) ON DELETE CASCADE;
ALTER TABLE action_results DROP CONSTRAINT IF EXISTS action_results_user_id_fkey;
ALTER TABLE action_results ADD CONSTRAINT action_results_user_id_fkey
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

COMMIT;
