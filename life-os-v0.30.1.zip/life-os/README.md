# LIFE OS

LIFE OS is a personal life-navigation app: it helps a person understand where they are, choose what matters, take small actions, learn from the results and adapt over time.

## Current version: v0.27

Implemented foundation:
- React Native + Expo Router mobile app
- Multilingual UI framework with 20 selectable languages, device-language detection, and locally persisted language preference (Portuguese, English, Spanish, French, German, Italian, Dutch, Chinese, Japanese, Korean, Arabic, Hindi, Russian, Turkish, Indonesian, Swahili, Bengali, Urdu, Ukrainian and Polish)
- Expanded screen translations for welcome/account, Today, life-map assessment/map, goals, insights, AI reflection, memory management and language selection; reviewed screen-copy packs currently cover Portuguese, English, Spanish, French, German, Chinese, Japanese and Arabic. Other selectable languages use existing translations where available and fall back to English for copy not yet translated.
- Initial right-to-left layout direction for Arabic and Urdu screens; visual verification on devices remains outstanding. Life-area labels are localized for the same eight reviewed screen-copy languages.
- NestJS API
- PostgreSQL + Prisma persistence
- authentication with bcrypt + JWT
- Life Map assessment and deterministic scoring
- Goals, actions and check-ins
- Adaptive Today / micro-actions engine
- Action-result learning signals
- deterministic Insights Engine and weekly review
- AI Gateway with configurable OpenAI-compatible chat-completions endpoint, timeout, response-shape validation and safe fallback
- AI chat screen in the mobile app
- explicit-consent AI memories API: list, add, edit/confirm and soft-delete
- mobile memory-management screen
- initial Safety Engine boundary
- timezone-aware calendar-day handling for check-ins and Today/action lists, including daylight-saving transitions
- unit tests for normal, 23-hour, and 25-hour days
- duplicate action-result submissions rejected when an action is no longer pending
- end-to-end journey regression test covering assessment, scored life map, goal creation, micro-action planning, action results and generated insights

## Core loop

`CONHECER → COMPREENDER → PRIORIZAR → AGIR → APRENDER → ADAPTAR`

## Run locally

Requirements: Node 20+ and PostgreSQL.

```bash
cp apps/api/.env.example apps/api/.env
# Set DATABASE_URL and a strong random JWT_SECRET. Configure AI_API_KEY only if you want live model responses.
npm install
npm run prisma:generate -w @life-os/api
npm run prisma:migrate -w @life-os/api
npm run build
npm run dev -w @life-os/api
```

For mobile:

```bash
npm run start -w @life-os/mobile
```

Set `EXPO_PUBLIC_API_URL` to an API URL reachable from the device. On a physical phone, `localhost` points to the phone, not your development computer.

## Verificações de segurança sem dependências externas

Na raiz do repositório, executa `npm run test:contracts` para correr testes de preflight, validar o contrato de chaves estrangeiras SQL/Prisma e verificar estaticamente os limites de segurança da exportação e eliminação de conta. Estas verificações são uma barreira de regressão inicial; não substituem testes HTTP, PostgreSQL real, revisão de segurança ou builds móveis.

## AI configuration

The AI provider is optional. Configure `AI_API_KEY`, `AI_API_URL` and `AI_MODEL` in the API environment. The gateway sends only the current user message and explicitly supplied context; it does not automatically save conversations as memories. The endpoint expects an OpenAI-compatible Chat Completions API. Provider failures fall back to a transparent non-personalized response.

Memories are created only through the authenticated `POST /memories` endpoint with explicit `consent: true`; the user can list, edit/confirm and soft-delete their own memories. This is a first implementation, not a complete privacy-management or GDPR solution.

## Important limitations

Not production-ready. The safety keyword classifier is incomplete and cannot reliably detect every crisis; emergency handling and country-specific resources need expert review. The AI provider integration needs tests, rate limiting, token/cost limits, abuse protection and privacy/security review. Also remaining: password recovery/email verification, stronger session management, full consent history, database migrations review, observability, CI/CD, backups, E2E tests, GDPR/legal review and iOS/Android release preparation. Account export/delete endpoints were added earlier but still require database-backed end-to-end validation and legal review. The v0.23 journey test uses an in-memory Prisma test double; it is not a substitute for PostgreSQL-backed integration tests. Never put AI provider secrets in the mobile app.

### v0.7 reflection-to-action flow

The reflection screen now supports saving suggested actions to Today and converting a reflection into an active goal. Creating a goal generates a starter plan of up to three persisted micro-actions via `POST /goals/:id/plan`. Today asks for a perceived-benefit and difficulty rating (0–10) when recording completed, partial, or skipped actions. This is an early deterministic baseline and requires integration testing before production.

### v0.9 user-led daily check-in

The Today screen no longer submits hard-coded mood, energy and stress values. The user selects each value (0–10), sees a saving state, receives visible error feedback if the request fails, and the saved indicator resets when they change a score. This keeps daily self-report user-led rather than inferred by the app.

### v0.8 adaptive action learning

The scoring package now exposes `scoreAdaptiveAction`, a deterministic, explainable heuristic that combines action priority, expected impact, confidence, effort, complexity, duration, current capacity, and recent action outcomes. `GET /today` uses the latest assessment per life area and recent results to rank actions, and returns an `adaptation.explanation` plus the evidence sample size for each action. The mobile Today screen shows the first explanation so users can understand why the plan was softened or reinforced.

The heuristic deliberately requires a small minimum sample before using historical benefit/difficulty signals. It is a transparent product heuristic, not a validated scientific or clinical model. New unit tests cover low-capacity ranking, high-difficulty adaptation, and a cautious benefit signal. Full workspace build/test still needs dependency installation in an environment with package registry access.

### v0.10 integration hardening

- `GET /checkins/latest` restores the latest check-in in Today; saving again on the same calendar day updates that day's record instead of creating an unnecessary duplicate.
- Action creation now verifies that any linked goal belongs to the authenticated user and is active; life-area IDs and date formats are validated.
- Goal updates use an explicit allow-list of editable fields, rather than passing an arbitrary request object into Prisma.
- Completing an action returns a proper 404 when the action is not owned by the authenticated user.
- Life-map validation errors are separated from database errors so unexpected persistence failures are not misreported as user input errors.
- Refreshing deterministic insights removes stale, non-dismissed generated snapshots before writing the current set, avoiding duplicate cards from repeated refreshes.

Validation performed for this package: five scoring tests pass; the scoring source compiles in isolation; TypeScript/TSX syntax-transpilation check passed for 39 source files. Full workspace type-check/build and PostgreSQL-backed integration tests are still pending because package installation timed out in this environment.


### v0.12 persisted life-map recovery and timezone resilience

The authenticated `GET /life-map/latest` endpoint returns the latest saved assessment for each life area, scoped to the current user and re-ranked for display. The mobile Map screen can recover this data if opened without navigation parameters, so the last map is not lost when in-memory route state disappears. Invalid or missing stored IANA timezone values now fall back to `Europe/Lisbon` for calendar-day calculations instead of breaking core Today, actions, or check-in requests. These changes still require a full workspace build and PostgreSQL-backed multi-user integration tests before a real-user pilot.


## v0.13 security and scheduling notes
- Goal starter actions use the account's IANA timezone when determining the local calendar-day start.
- Action creation rejects whitespace-only titles.
- API regression tests cover user-scoped action completion, goal plan access, memory access, explicit memory consent and duplicate action completion protection.
- These controller tests use mocked persistence; run them and add PostgreSQL-backed integration tests in a dependency-enabled environment before a real-user pilot.


### v0.14 multilingual foundation
- Added an in-app language picker reachable from the welcome, sign-in and Today screens.
- The app detects a supported device locale on first launch and remembers a manually selected language securely on the device.
- Initial translations cover the welcome/account and daily check-in/action flow across 20 languages. The framework falls back to English or Portuguese for keys not yet translated.
- This is a first localization layer, not a claim that every screen and every phrase is fully translated. Full translation of all screens, professional linguistic review, right-to-left layout verification (Arabic/Urdu), and country-specific emergency/help content remain before production.


### v0.15 expanded internationalization
- Added shared screen-copy catalogue and applied it to assessment, map, goals, insights, reflection-to-action and memory-management screens.
- Added localized life-area labels for Portuguese, English, Spanish, French, German, Simplified Chinese, Japanese and Arabic.
- Added initial RTL direction handling for Arabic and Urdu screens. The layout still needs native-device QA, especially mixed-direction text and form controls.
- Corrected privacy copy that previously implied account export/deletion was already available. At v0.15, full account export/deletion was not implemented; endpoints and a mobile privacy screen were added in v0.17, with production validation still pending.
- Translation coverage is deliberately reported accurately: 20 languages can be selected, but extended screen copy has reviewed translations for 8 languages; the remaining languages use existing translations where a matching key exists and English fallback for the rest. Professional review and broader coverage remain necessary before claiming full global localization.
- Validation: syntax-transpilation checks performed across the TypeScript/TSX source; full Expo typecheck/build and device-level RTL checks were not available because dependencies are not installed in this environment.


## v0.16 internationalization update
The mobile app now shares locale-aware date/number/percentage helpers across the 20 language choices, formats goal deadlines using the selected language, centralizes Arabic/Urdu RTL classification, and includes translated labels for all ten life areas in every selectable language. This is a multilingual foundation, not yet a fully human-reviewed translation of every screen. See `docs/IMPLEMENTATION_STATUS.md` for the exact coverage and outstanding validation.


## v0.17 account privacy controls

- Added authenticated `GET /account/export`, which exports the current user's profile fields (excluding password hashes) and their assessments, goals, actions, action results, check-ins, memories, and insights. Every data query is scoped by the authenticated user ID.
- Added authenticated `DELETE /account`. Permanent deletion requires the current account email, current password, and the exact confirmation phrase `DELETE MY ACCOUNT`; the API relies on database cascade constraints for related user-owned records.
- Added a mobile Account & Privacy screen to share/save the JSON export and request permanent deletion. The screen clears the local session after successful deletion.
- Added controller tests for export scoping/credential exclusion and the destructive-confirmation gate.

Validation limitation: full Nest/Prisma/Expo builds, database cascade behavior, and end-to-end account deletion have not been run in this environment because workspace dependencies and a PostgreSQL test database are not installed. Before production, verify database foreign-key cascade behavior against a real migration, add rate limiting/re-authentication policy review, and have privacy counsel review retention and legal obligations. Export sharing may expose sensitive data through the device's share sheet; users should save/share it only to trusted destinations.

### Account privacy API

- `GET /account/export` — bearer token required. Returns a JSON snapshot of the authenticated account's profile (excluding credential hashes), life-area assessments, goals, actions, action results, check-ins, memories and insights.
- `DELETE /account` — bearer token required. JSON body: `{ "email": "account@example.com", "password": "current password", "confirmation": "DELETE MY ACCOUNT" }`. The API checks the authenticated account's email and password before permanent deletion. Treat this as destructive and test cascade behavior on a disposable database first.


## v0.18 — Privacy and API boundary hardening
- Account data export response includes `Cache-Control: no-store, private` and `Pragma: no-cache` to discourage browser/proxy caching of sensitive data.
- Added focused controller tests for account-export user scoping, credential exclusion, and destructive-confirmation behavior.
- Browser CORS origins are now allow-listed through `CORS_ORIGINS` (comma-separated exact origins); native clients without an `Origin` header remain supported. CORS is not an authentication mechanism and every API route still requires its own access controls.
- Added a pure CORS-policy unit test for allowed, denied and origin-less requests.

Before production, configure `CORS_ORIGINS` for the exact deployed web origin(s), run all API tests with dependencies installed, verify account deletion against a disposable PostgreSQL database, and complete an independent security/privacy review. No claim of GDPR compliance or production readiness is made by these changes.


## v0.19 — Exportação de dados em ficheiro

- A exportação de dados na aplicação móvel passa a gerar um ficheiro JSON temporário e abrir a folha nativa de partilha, em vez de colocar todo o conteúdo apenas como texto da mensagem de partilha.
- O ficheiro temporário é removido depois de a folha de partilha fechar, sempre que o sistema operativo permitir.
- Se a partilha nativa não estiver disponível, a aplicação mantém uma alternativa de partilha de texto.
- A exportação contém informação pessoal; partilha-a apenas com destinos em que confies.
- A versão da aplicação móvel foi atualizada para 0.19.0.

Validação: verificações de sintaxe TypeScript/TSX e integridade do arquivo ZIP. A instalação das dependências, compilação Expo, partilha real em iOS/Android e testes ponta a ponta continuam pendentes neste ambiente.


## Versão móvel 0.20.0

A versão móvel e a versão Expo estão alinhadas em `0.20.0`. Para verificar regressões no catálogo de idiomas e na formatação localizada, executa `npm run test:locale -w @life-os/mobile` num ambiente com dependências instaladas. Esta verificação cobre a presença dos 20 idiomas, tags de localidade, direção RTL e formatadores de data/número/percentagem; não substitui revisão linguística humana nem testes de dispositivo.

### Health checks da API

- `GET /health/live` — verifica se o processo da API responde, sem consultar serviços externos.
- `GET /health/ready` — verifica se a base de dados responde a uma consulta simples; em caso de falha devolve HTTP 503 com uma resposta sanitizada.

Em deployments, usa `/health/live` para liveness e `/health/ready` para readiness. Estes endpoints não validam toda a aplicação nem substituem monitorização e testes de integração.


## v0.22 — validação robusta da avaliação e da matriz de influência

- A avaliação valida agora números finitos, intervalos 0–10 e dez áreas distintas conhecidas.
- A matriz de influência opcional é validada antes de qualquer gravação: áreas de origem/destino conhecidas, pesos finitos entre 0 e 5 e sem auto-influência.
- Adicionados testes unitários para dados inválidos e para garantir que uma matriz inválida não inicia persistência.
- Versão móvel alinhada em `0.22.0`.

Os scores e a matriz de influência continuam a ser heurísticas de produto, não medidas científicas ou clínicas. A validação de entrada reduz corrupção acidental, mas não substitui testes de integração com PostgreSQL.


### v0.23 — Full user-journey regression test

Added `apps/api/test/journey.test.ts`, a stateful in-memory test that exercises the real Life Map, Goals, Actions and Insights controllers/services in sequence: persist ten assessment areas, score the life map, create an active goal, generate three pending micro-actions, record their outcomes, and refresh insights. The test checks expected state transitions and that the insight engine can derive consistency, action-effect and priority signals from the stored sample.

Validation in this environment: 60 TypeScript/TSX files passed syntax transpilation; the journey test passed when run against the actual controllers/services with lightweight runtime stubs for unavailable framework dependencies. This is useful regression coverage but does not constitute a full NestJS build, framework-level HTTP test, or PostgreSQL integration test. Those remain required before a real-user pilot.

### v0.24 — account deletion integrity

The SQL bootstrap schema, Prisma model and upgrade migration now express a consistent cascade policy for permanent account deletion. For an existing database, review and test `db/migrations/20261009_account_deletion_cascade.sql` against a backup or disposable PostgreSQL database before applying it to any real user data. The included schema tests are static checks and do not prove that a migration succeeds against a live database.

## Verificação do contrato de base de dados

Antes de alterar o esquema, executa `npm run verify:db-contract` na raiz para detetar divergências entre o SQL de instalação, a migração de cascata e as relações Prisma. O comando não precisa de dependências instaladas, mas é uma verificação estática: não substitui a execução da migração e os testes de eliminação de conta numa base PostgreSQL de staging.

## Preflight de implementação (v0.26)

Antes de validar um ambiente, executa `npm run preflight` e `npm run test:preflight`. Para validar variáveis de um ambiente de staging/produção, configura-as no processo e executa `npm run preflight:production`. O verificador não lê ficheiros `.env` nem substitui testes reais de integração ou uma auditoria de segurança. Consulta `RELEASE_NOTES_v0.26.md`.

## v0.28 — CI e preparação de lançamento

A versão 0.28 declara explicitamente `@prisma/client` como dependência da API e adiciona um workflow GitHub Actions para gerar o cliente Prisma, executar testes/contratos e fazer typecheck da API e da aplicação móvel. Executa `npm run test:contracts` para as verificações locais sem serviços externos. O workflow CI só está validado quando terminar com sucesso num runner real; os testes locais não substituem integração PostgreSQL nem builds móveis.

## v0.29 — integração PostgreSQL

A versão 0.29 acrescenta um teste de integração opcional com PostgreSQL para verificar persistência entre instâncias Prisma, isolamento de consultas por utilizador e cascata de eliminação dos dados associados. Com uma base de dados descartável configurada em `DATABASE_URL` e o cliente Prisma gerado, executa `npm run test:postgres`. Sem `DATABASE_URL`, o teste fica ignorado. O workflow CI prepara um serviço PostgreSQL efémero e executa este teste; o resultado real só pode ser confirmado após a execução do workflow num runner. Não uses `prisma db push` como substituto das migrações de produção.


### v0.30 — testes executáveis de autenticação

- Adicionados testes de unidade para o `AuthGuard`: cabeçalho ausente/inválido, token malformado, expirado, assinado com segredo errado, claims verificadas e ausência de `JWT_SECRET`.
- Adicionados testes de `AuthService`: registo, hash de palavra-passe, normalização de email, email duplicado, login inválido e emissão/verificação de token.
- Corrigida a normalização de email para remover espaços exteriores antes de converter para minúsculas, tanto no registo como no login.
- Declarado `@types/node` como dependência de desenvolvimento explícita.
- Versões móvel e Expo alinhadas em `0.30.0`.


### v0.30.1 — arranque de dependências e CI

- Removida a cache npm dependente de lockfile inexistente no `setup-node`.
- Instalação do CI com retries e artefacto do `package-lock.json` para recuperação após execução bem-sucedida.
- Teste de contrato para a configuração de bootstrap.
- Versões móvel/Expo alinhadas em `0.30.1`.
