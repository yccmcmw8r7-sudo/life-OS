# LIFE OS v0.19

## Exportação de dados mais utilizável

A secção Conta e Privacidade passa a criar um ficheiro JSON temporário com a exportação da conta e a abrir a folha nativa de partilha do iOS/Android. Isto facilita guardar uma cópia como ficheiro, em vez de depender de uma mensagem de texto com todo o JSON.

- Usa `expo-file-system/legacy` para gravar o ficheiro temporário na sandbox da aplicação.
- Usa `expo-sharing` para partilhar o ficheiro com aplicações compatíveis.
- Tenta remover o ficheiro temporário quando a partilha termina ou é cancelada.
- Mantém uma alternativa de partilha de texto se a partilha nativa não estiver disponível.
- Atualiza a versão da aplicação móvel para `0.19.0`.

## Segurança e limitações

O ficheiro contém dados pessoais e deve ser partilhado apenas com destinos de confiança. A limpeza do ficheiro é best-effort e depende do sistema operativo. A funcionalidade ainda precisa de testes reais em iOS e Android.

## Verificação

A validação desta entrega limita-se à análise de sintaxe TypeScript/TSX e à integridade do ZIP. A instalação das dependências, o typecheck completo, o bundle Expo e os testes de partilha em dispositivos não foram executados neste ambiente.
