# LIFE OS v0.29

## Foco: primeira integração com PostgreSQL real

- Adicionado `apps/api/test/integration/postgres-account-data.test.ts`, um teste de integração executado apenas quando `DATABASE_URL` está definido.
- O teste confirma que dados confirmados são visíveis a uma segunda instância Prisma, que as consultas por `userId` mantêm isolamento entre contas e que apagar uma conta elimina os registos associados sem apagar os dados de outra conta.
- Adicionado `npm run test:integration -w @life-os/api` e o atalho de workspace `npm run test:postgres`.
- O workflow CI prepara uma instância PostgreSQL descartável, aplica o schema Prisma com `prisma db push` e executa o teste de integração.
- Versão móvel/Expo atualizada para `0.29.0`.

## Limites de validação

O teste requer dependências instaladas, cliente Prisma gerado e uma base PostgreSQL descartável. Se `DATABASE_URL` não estiver definido, o teste é marcado como ignorado; isso não deve ser interpretado como validação de integração. O workflow precisa de ser executado num runner real para confirmar a integração end-to-end. `prisma db push` é usado apenas no banco descartável do CI, não como estratégia de migração de produção.
