# LIFE OS v0.18 — Privacy and API boundary hardening

## Changes
- Account export responses now send `Cache-Control: no-store, private` and `Pragma: no-cache`.
- Added focused API tests for export scoping, exclusion of password hashes, and destructive account-deletion confirmation.
- Browser CORS is restricted to exact origins configured in `CORS_ORIGINS` (comma-separated). Requests without an `Origin` header remain allowed for native mobile clients.
- Added unit tests for the CORS policy.

## Configure CORS
Set `CORS_ORIGINS` in the API environment to exact deployed web origins, for example:

`CORS_ORIGINS=https://app.example.com,https://admin.example.com`

Do not add a trailing slash to origins. Native mobile requests normally have no `Origin` header. CORS is not authentication; use authenticated endpoints and authorization checks as before.

## Validation
- 55 TypeScript/TSX files passed syntax transpilation.
- The standalone CORS policy compiled with strict TypeScript and passed runtime smoke checks.
- Full API tests, full workspace type-check/build, Prisma/PostgreSQL integration tests, Expo bundling and iOS/Android device tests remain pending because project dependencies are not installed in this environment.

## Not production-ready
These changes do not establish GDPR compliance or production readiness. Complete dependency-backed tests, database deletion/export verification, security review, retention policy, backups, monitoring, account recovery, and native-device QA before launch.
