# LIFE OS v0.22

## Segurança e integridade da avaliação
- Validação de dez áreas de vida distintas e conhecidas.
- Ratings precisam de ser números finitos entre 0 e 10.
- Matriz de influência opcional validada antes da persistência.
- Pesos precisam de ser finitos e estar entre 0 e 5; áreas desconhecidas e auto-influência são rejeitadas.
- Testes de regressão para entradas malformadas e ausência de gravação quando a matriz é inválida.
- Versão móvel/Expo: `0.22.0`.

## Validação
Verificar a sintaxe TypeScript/TSX, JSON e integridade do ZIP. Os testes completos da API, o typecheck com dependências, o build Expo e a integração PostgreSQL continuam pendentes neste ambiente.
