# LIFE OS v0.24 — Account deletion integrity

## What changed

- Aligned the bootstrap SQL schema with the intended account-deletion behavior: deleting a user cascades to assessments, goals, actions, check-ins, AI memories, insights, and action results.
- Added an upgrade migration to repair existing PostgreSQL foreign-key deletion rules. Goal deletion now sets an action's optional `goal_id` to `NULL`; deleting an action cascades to its results.
- Added an explicit `User` relation for `ActionResult` in Prisma so the ORM schema documents the same user-owned data relationship as SQL.
- Added static regression tests that compare the fresh-install SQL, upgrade migration, and Prisma relation expectations.
- Aligned the mobile package and Expo app version at `0.24.0`.

## Important deployment note

Account deletion is permanent. Back up the database and run the migration first in a disposable/staging database. Verify the migration against the actual deployed schema and existing constraint names before production. These tests inspect SQL definitions; they do **not** execute the migration against PostgreSQL. Full Prisma generation, API tests, Expo builds, and device tests remain outstanding.
