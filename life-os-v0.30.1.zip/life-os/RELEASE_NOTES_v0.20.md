# LIFE OS v0.20 — qualidade de localização e controlo de versão

## Alterações
- Alinhada a versão declarada da aplicação Expo e do pacote móvel em `0.20.0`, evitando metadados de lançamento contraditórios.
- Adicionados testes de regressão para o catálogo de 20 idiomas, unicidade dos códigos, cobertura de mensagens, tags BCP-47, suporte `Intl`, direção RTL e formatação de datas/números/percentagens.
- Disponibilizado o comando `npm run test:locale -w @life-os/mobile` para executar os testes de localização no ambiente com dependências instaladas.

## Validação desta entrega
- Verificada a sintaxe TypeScript/TSX de todos os ficheiros de origem e teste.
- Compilados isoladamente os utilitários de localização e os respetivos testes com TypeScript global.
- Executados os testes compilados com o runner nativo do Node.js.
- Verificado o alinhamento da versão `0.20.0` entre `apps/mobile/package.json` e `apps/mobile/app.json`.
- Verificada a integridade do arquivo ZIP.

## Limitações
Os testes de localização não substituem revisão humana das traduções nem testes em dispositivos. A compilação completa do Expo, o typecheck completo dos workspaces, a suite API e a integração com PostgreSQL continuam pendentes até as dependências do projeto poderem ser instaladas num ambiente adequado.
