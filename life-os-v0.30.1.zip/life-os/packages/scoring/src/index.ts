export type LifeAreaId =
  | 'RELATIONSHIPS' | 'FAMILY_FRIENDS' | 'EMOTIONAL_WELLBEING' | 'HEALTH_ENERGY'
  | 'FINANCES' | 'CAREER' | 'AUTONOMY' | 'PURPOSE' | 'PLEASURE' | 'GROWTH';

export interface Assessment {
  areaId: LifeAreaId;
  satisfaction: number;
  importance: number;
  motivation: number;
  capacity: number;
}

export interface ScoredArea extends Assessment {
  gap: number;
  gapNormalized: number;
  priority: number;
  dominoImpact: number;
  dominoScore: number;
}

export const clamp = (n:number,min=0,max=10) => Math.max(min, Math.min(max,n));
export const normalize10 = (n:number) => clamp(n)/10;

export function scoreAssessment(a: Assessment): ScoredArea {
  const satisfaction=clamp(a.satisfaction), importance=clamp(a.importance), motivation=clamp(a.motivation), capacity=clamp(a.capacity);
  const gap=importance-satisfaction;
  const gapNormalized=gap/10;
  const priority=Math.max(0, gapNormalized) * normalize10(motivation) * (0.5+0.5*normalize10(capacity)) * (0.5+0.5*normalize10(importance));
  return {...a,satisfaction,importance,motivation,capacity,gap,gapNormalized,priority,dominoImpact:0,dominoScore:priority};
}

export type DominoMatrix = Partial<Record<LifeAreaId, Partial<Record<LifeAreaId, number>>>>;

export function applyDomino(areas: ScoredArea[], matrix: DominoMatrix): ScoredArea[] {
  const byId=new Map(areas.map(a=>[a.areaId,a]));
  return areas.map(source=>{
    let impact=0;
    for(const target of areas){
      if(target.areaId===source.areaId) continue;
      const weight=clamp(matrix[source.areaId]?.[target.areaId] ?? 0,0,5)/5;
      impact += weight * Math.max(0,target.gapNormalized) * normalize10(target.importance);
    }
    const maxPossible=Math.max(1, areas.length-1);
    const normalized=Math.min(1, impact/maxPossible);
    return {...source,dominoImpact:normalized,dominoScore:source.priority*(1+normalized)};
  });
}

export interface ActionCandidate { id:string; relevance:number; expectedImpact:number; capacity:number; confidence:number; friction:number; }
export function rankActions(actions:ActionCandidate[]):ActionCandidate[] {
  return [...actions].map(a=>({...a, relevance:clamp(a.relevance)/10, expectedImpact:clamp(a.expectedImpact)/10, capacity:clamp(a.capacity)/10, confidence:clamp(a.confidence)/10, friction:Math.max(0.1,clamp(a.friction)/10)}))
    .sort((a,b)=>(b.relevance*b.expectedImpact*b.capacity*b.confidence/b.friction)-(a.relevance*a.expectedImpact*a.capacity*a.confidence/a.friction));
}

export { scoreAdaptiveAction } from './adaptive.js';
export type { ActionSignals, AdaptiveScore, CompletionState } from './adaptive.js';
