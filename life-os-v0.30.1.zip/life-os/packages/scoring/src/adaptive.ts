/** Personalisation heuristics for daily actions. These are product rules, not clinical claims. */
export type CompletionState = 'COMPLETED' | 'PARTIAL' | 'SKIPPED';
export interface ActionSignals {
  priority: number;
  expectedImpact?: number | null; // 0–10
  confidence?: number | null; // 0–10
  effort?: number | null; // 0–10
  complexity?: number | null; // 0–10
  estimatedMinutes?: number | null;
  areaCapacity?: number | null; // 0–10
  latestCompletion?: CompletionState | null;
  averageDifficulty?: number | null; // 0–10
  averageBenefit?: number | null; // 0–10
  sampleSize?: number;
}
export interface AdaptiveScore { score: number; effortFactor: number; capacityFactor: number; learningFactor: number; explanation: string[] }
const clamp = (n:number,min=0,max=10) => Math.max(min,Math.min(max,n));
export function scoreAdaptiveAction(a: ActionSignals): AdaptiveScore {
  const effort = clamp(a.effort ?? 3);
  const complexity = clamp(a.complexity ?? 2);
  const minutes = Math.max(1, a.estimatedMinutes ?? 10);
  const capacity = clamp(a.areaCapacity ?? 6);
  const sample = Math.max(0, a.sampleSize ?? 0);
  const base = Math.max(0,a.priority) * (0.6 + 0.4 * clamp(a.expectedImpact ?? 5)/10) * (0.6 + 0.4 * clamp(a.confidence ?? 5)/10);
  const effortFactor = Math.max(0.35, 1 - ((effort * 0.45 + complexity * 0.35 + Math.min(minutes,60)/10 * 0.2) / 10));
  const capacityFactor = capacity <= 3 ? 0.55 : capacity <= 5 ? 0.78 : capacity <= 7 ? 0.92 : 1;
  let learningFactor = 1;
  const explanation:string[] = [];
  if (capacity <= 3) explanation.push('Energia baixa: foi dada preferência a passos mais leves.');
  if (sample >= 2) {
    if ((a.averageDifficulty ?? 0) >= 7) { learningFactor *= 0.8; explanation.push('O histórico sugere que ações semelhantes têm sido difíceis; reduzimos a exigência.'); }
    if ((a.averageBenefit ?? 0) >= 7) { learningFactor *= 1.12; explanation.push('Registaste benefício elevado em ações semelhantes; este tipo de passo recebe um pequeno reforço.'); }
    if (a.latestCompletion === 'SKIPPED') { learningFactor *= 0.82; explanation.push('A última tentativa foi adiada; vamos evitar aumentar a pressão.'); }
    if (a.latestCompletion === 'PARTIAL') { learningFactor *= 0.92; explanation.push('Uma versão mais pequena pode ser mais adequada depois de uma tentativa parcial.'); }
    if (a.latestCompletion === 'COMPLETED' && (a.averageDifficulty ?? 0) <= 4) { learningFactor *= 1.04; explanation.push('As últimas tentativas parecem ter sido geríveis; mantemos o passo com um ligeiro reforço.'); }
  }
  if (!explanation.length) explanation.push('Ainda há poucos dados pessoais; a prioridade inicial é uma estimativa e será ajustada com o teu feedback.');
  return { score: base * effortFactor * capacityFactor * learningFactor, effortFactor, capacityFactor, learningFactor, explanation };
}
