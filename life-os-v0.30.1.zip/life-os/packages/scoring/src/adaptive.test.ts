import test from 'node:test';
import assert from 'node:assert/strict';
import { scoreAdaptiveAction } from './adaptive.js';

test('low capacity makes demanding actions less competitive', () => {
 const easy = scoreAdaptiveAction({priority:1, effort:1, complexity:1, estimatedMinutes:5, areaCapacity:2});
 const demanding = scoreAdaptiveAction({priority:1, effort:8, complexity:8, estimatedMinutes:45, areaCapacity:2});
 assert.ok(easy.score > demanding.score);
});
test('learning lowers score after repeated high difficulty', () => {
 const baseline = scoreAdaptiveAction({priority:1, effort:3, complexity:2, estimatedMinutes:10, areaCapacity:6, sampleSize:1});
 const learned = scoreAdaptiveAction({priority:1, effort:3, complexity:2, estimatedMinutes:10, areaCapacity:6, sampleSize:3, averageDifficulty:9, latestCompletion:'PARTIAL'});
 assert.ok(learned.score < baseline.score);
});
test('high reported benefit gives a cautious boost with enough observations', () => {
 const baseline = scoreAdaptiveAction({priority:1, sampleSize:2, averageBenefit:3});
 const learned = scoreAdaptiveAction({priority:1, sampleSize:3, averageBenefit:8});
 assert.ok(learned.score > baseline.score);
});
