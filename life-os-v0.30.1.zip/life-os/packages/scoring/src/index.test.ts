import test from 'node:test';
import assert from 'node:assert/strict';
import {scoreAssessment,applyDomino} from './index.js';
test('high gap and motivation produce higher priority',()=>{
 const a=scoreAssessment({areaId:'HEALTH_ENERGY',satisfaction:2,importance:10,motivation:9,capacity:8});
 const b=scoreAssessment({areaId:'CAREER',satisfaction:7,importance:8,motivation:9,capacity:8});
 assert.ok(a.priority>b.priority);
});
test('domino impact increases domino score',()=>{
 const areas=[scoreAssessment({areaId:'HEALTH_ENERGY',satisfaction:3,importance:10,motivation:8,capacity:8}),scoreAssessment({areaId:'EMOTIONAL_WELLBEING',satisfaction:3,importance:10,motivation:7,capacity:7})];
 const out=applyDomino(areas,{HEALTH_ENERGY:{EMOTIONAL_WELLBEING:5}});
 assert.ok(out[0].dominoScore>out[0].priority);
});
