# Prisma

From the repository root:

```bash
npm install
npm run prisma:generate -w @life-os/api
npm run prisma:migrate -w @life-os/api
```

Set `DATABASE_URL` in `apps/api/.env` first.

The v0.5 Insights Engine uses the existing `Insight` model and does not require a new table. It reads recent `ActionResult`, `Checkin`, `LifeAreaAssessment` and active `Goal` records.

## Account-deletion cascade migration (v0.24)

For an existing PostgreSQL database, review and test `db/migrations/20261009_account_deletion_cascade.sql` from the repository root against a backup or disposable database before applying it. The migration intentionally enables permanent deletion of user-owned records and sets an action's optional goal reference to `NULL` if a goal is deleted. It has not been executed against a live PostgreSQL server in this build environment.
