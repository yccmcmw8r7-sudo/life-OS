import test from 'node:test';
import assert from 'node:assert/strict';
import { LifeMapController } from '../src/life-map/life-map.controller.js';

function makeController(records: any[]) {
  let capturedQuery: any;
  const db = {
    lifeAreaAssessment: {
      findMany: async (query: any) => { capturedQuery = query; return records; },
    },
  };
  const service = { evaluate: () => [] };
  return { controller: new LifeMapController(service as any, db as any), query: () => capturedQuery };
}

test('latest life map is scoped to the authenticated user and returns one latest record per area', async () => {
  const { controller, query } = makeController([
    { areaId: 'HEALTH_ENERGY', satisfaction: 4, importance: 9, motivation: 7, capacity: 5, createdAt: new Date('2026-10-08T10:00:00Z') },
    { areaId: 'PURPOSE', satisfaction: 3, importance: 8, motivation: 6, capacity: 4, createdAt: new Date('2026-10-08T09:00:00Z') },
  ]);
  const result = await controller.latest({ user: { sub: 'user-a' } });
  assert.equal(query().where.userId, 'user-a');
  assert.deepEqual(query().distinct, ['areaId']);
  assert.equal(result.length, 2);
  assert.ok(result[0].dominoScore >= result[1].dominoScore);
});

test('latest life map returns an empty list when the user has no saved assessments', async () => {
  const { controller } = makeController([]);
  assert.deepEqual(await controller.latest({ user: { sub: 'user-a' } }), []);
});
