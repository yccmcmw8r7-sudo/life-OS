import test from 'node:test';
import assert from 'node:assert/strict';
import { ActionsController } from '../src/actions/actions.controller.js';
import { NotFoundException, ConflictException, BadRequestException } from '@nestjs/common';

function makeController(action: any = null) {
  const calls: any[] = [];
  const tx = {
    action: {
      findFirst: async (query: any) => { calls.push(['findFirst', query]); return action; },
      update: async (query: any) => { calls.push(['update', query]); return query; },
    },
    actionResult: { create: async (query: any) => { calls.push(['resultCreate', query]); return query.data; } },
  };
  const db = {
    $transaction: async (fn: any) => fn(tx),
    action: { create: async (query: any) => query.data },
    goal: { findFirst: async () => null },
  };
  return { controller: new ActionsController(db as any), calls };
}

test('completion query is scoped to authenticated user', async () => {
  const { controller, calls } = makeController(null);
  await assert.rejects(() => controller.complete({ user: { sub: 'user-a' } }, 'action-x', { completion: 'COMPLETED' }), NotFoundException);
  assert.deepEqual(calls[0][1].where, { id: 'action-x', userId: 'user-a' });
  assert.equal(calls.some(([name]) => name === 'resultCreate'), false);
});

test('a non-pending action cannot receive a second completion result', async () => {
  const { controller, calls } = makeController({ id: 'action-x', status: 'COMPLETED' });
  await assert.rejects(() => controller.complete({ user: { sub: 'user-a' } }, 'action-x', { completion: 'COMPLETED' }), ConflictException);
  assert.equal(calls.some(([name]) => name === 'resultCreate'), false);
});

test('blank action titles are rejected before persistence', async () => {
  const { controller } = makeController();
  await assert.rejects(() => controller.create({ user: { sub: 'user-a' } }, { title: '   ' }), BadRequestException);
});
