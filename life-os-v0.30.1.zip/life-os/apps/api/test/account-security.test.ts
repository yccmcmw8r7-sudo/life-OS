import test from 'node:test';
import assert from 'node:assert/strict';
import { BadRequestException, UnauthorizedException } from '@nestjs/common';
import { AccountController } from '../src/account/account.controller.js';

function makeDb() {
  const calls: Record<string, any[]> = {};
  const record = (name: string, result: any) => async (query: any) => {
    (calls[name] ??= []).push(query);
    return result;
  };
  const db = {
    user: {
      findUnique: record('user.findUnique', { id: 'user-a', email: 'a@example.com', name: 'A', timezone: 'Europe/Lisbon', language: 'pt-PT', createdAt: new Date(0), updatedAt: new Date(0), passwordHash: 'not-a-real-hash' }),
      delete: record('user.delete', { id: 'user-a' }),
    },
    lifeAreaAssessment: { findMany: record('assessments', []) },
    goal: { findMany: record('goals', []) },
    action: { findMany: record('actions', []) },
    actionResult: { findMany: record('actionResults', []) },
    checkin: { findMany: record('checkins', []) },
    aiMemory: { findMany: record('memories', []) },
    insight: { findMany: record('insights', []) },
  };
  return { db, calls };
}

test('account export scopes every data query to the authenticated account and omits credentials', async () => {
  const { db, calls } = makeDb();
  const controller = new AccountController(db as any);
  const result = await controller.exportData({ user: { sub: 'user-a' } });
  assert.equal(result.format, 'life-os-export');
  assert.equal(result.user.id, 'user-a');
  assert.equal('passwordHash' in result.user, false);
  for (const name of ['assessments', 'goals', 'actions', 'actionResults', 'checkins', 'memories', 'insights']) {
    assert.deepEqual(calls[name][0].where, { userId: 'user-a' });
  }
  assert.deepEqual(calls['user.findUnique'][0], {
    where: { id: 'user-a' },
    select: { id: true, email: true, name: true, timezone: true, language: true, createdAt: true, updatedAt: true },
  });
});

test('account deletion refuses to proceed without the exact destructive confirmation phrase', async () => {
  const { db, calls } = makeDb();
  const controller = new AccountController(db as any);
  await assert.rejects(
    () => controller.deleteAccount({ user: { sub: 'user-a' } }, { email: 'a@example.com', password: 'some-password', confirmation: 'delete my account' }),
    BadRequestException,
  );
  assert.equal(calls['user.findUnique'], undefined);
  assert.equal(calls['user.delete'], undefined);
});

test('account deletion does not delete the account when email or password verification fails', async () => {
  const { db, calls } = makeDb();
  const controller = new AccountController(db as any);
  await assert.rejects(
    () => controller.deleteAccount({ user: { sub: 'user-a' } }, { email: 'someone-else@example.com', password: 'some-password', confirmation: 'DELETE MY ACCOUNT' }),
    UnauthorizedException,
  );
  assert.equal(calls['user.delete'], undefined);
});
