import test from 'node:test';
import assert from 'node:assert/strict';
import { PrismaClient } from '@prisma/client';
import { randomUUID } from 'node:crypto';

const enabled = Boolean(process.env.DATABASE_URL);

test('PostgreSQL persists user data, isolates user-scoped records, and cascades account deletion', { skip: !enabled }, async () => {
  const db = new PrismaClient();
  const suffix = randomUUID();
  let ownerId: string | undefined;
  let otherId: string | undefined;

  try {
    const owner = await db.user.create({ data: { email: `owner-${suffix}@example.test`, passwordHash: 'integration-test-hash' } });
    ownerId = owner.id;
    const other = await db.user.create({ data: { email: `other-${suffix}@example.test`, passwordHash: 'integration-test-hash' } });
    otherId = other.id;

    const goal = await db.goal.create({ data: { userId: owner.id, title: 'Teste de persistência', goalType: 'PROCESS' } });
    const action = await db.action.create({ data: { userId: owner.id, goalId: goal.id, title: 'Pequena ação de teste' } });
    await db.actionResult.create({ data: { userId: owner.id, actionId: action.id, completion: 'COMPLETED' } });
    await db.lifeAreaAssessment.create({ data: { userId: owner.id, areaId: 'GROWTH', satisfaction: 5, importance: 8, motivation: 6, capacity: 5 } });
    await db.checkin.create({ data: { userId: owner.id, mood: 6, energy: 5 } });
    await db.aiMemory.create({ data: { userId: owner.id, category: 'preference', content: 'temporary integration fixture' } });
    await db.insight.create({ data: { userId: owner.id, type: 'TEST', title: 'Fixture', description: 'temporary integration fixture' } });
    await db.goal.create({ data: { userId: other.id, title: 'Objetivo de outra conta', goalType: 'OUTCOME' } });

    // A new client observes committed data, demonstrating database persistence rather than in-memory state.
    const secondClient = new PrismaClient();
    try {
      assert.equal(await secondClient.goal.count({ where: { userId: owner.id } }), 1);
      assert.equal(await secondClient.action.count({ where: { userId: owner.id } }), 1);
      assert.equal(await secondClient.goal.count({ where: { userId: other.id } }), 1);
      assert.equal(await secondClient.goal.count({ where: { userId: owner.id, title: 'Objetivo de outra conta' } }), 0);
    } finally {
      await secondClient.$disconnect();
    }

    await db.user.delete({ where: { id: owner.id } });
    assert.equal(await db.lifeAreaAssessment.count({ where: { userId: owner.id } }), 0);
    assert.equal(await db.goal.count({ where: { userId: owner.id } }), 0);
    assert.equal(await db.action.count({ where: { userId: owner.id } }), 0);
    assert.equal(await db.actionResult.count({ where: { userId: owner.id } }), 0);
    assert.equal(await db.checkin.count({ where: { userId: owner.id } }), 0);
    assert.equal(await db.aiMemory.count({ where: { userId: owner.id } }), 0);
    assert.equal(await db.insight.count({ where: { userId: owner.id } }), 0);
    assert.equal(await db.goal.count({ where: { userId: other.id } }), 1, 'deleting one account must not remove another account\'s data');
  } finally {
    if (ownerId) await db.user.deleteMany({ where: { id: ownerId } });
    if (otherId) await db.user.deleteMany({ where: { id: otherId } });
    await db.$disconnect();
  }
});
