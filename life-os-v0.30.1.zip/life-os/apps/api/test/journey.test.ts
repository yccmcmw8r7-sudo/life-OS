import test from 'node:test';
import assert from 'node:assert/strict';
import { LifeMapController } from '../src/life-map/life-map.controller.js';
import { LifeMapService } from '../src/life-map/life-map.service.js';
import { GoalsController } from '../src/goals/goals.controller.js';
import { ActionsController } from '../src/actions/actions.controller.js';
import { InsightsService } from '../src/insights/insights.service.js';

const userId = 'pilot-user';
const areaIds = [
  'RELATIONSHIPS', 'FAMILY_FRIENDS', 'EMOTIONAL_WELLBEING', 'HEALTH_ENERGY',
  'FINANCES', 'CAREER', 'AUTONOMY', 'PURPOSE', 'PLEASURE', 'GROWTH',
];

/** Small stateful Prisma test double: exercises the real controllers/services without a database. */
function makeDb() {
  const state: any = {
    user: { id: userId, timezone: 'Europe/Lisbon', email: 'pilot@example.test', passwordHash: 'not-exported' },
    assessments: [], goals: [], actions: [], results: [], checkins: [], memories: [], insights: [],
  };
  let nextId = 1;
  const id = () => `row-${nextId++}`;
  const db: any = {
    user: { findUnique: async () => ({ ...state.user }) },
    lifeAreaAssessment: {
      create: async ({ data }: any) => { const row = { id: id(), createdAt: new Date(), ...data }; state.assessments.push(row); return row; },
      findMany: async ({ where }: any = {}) => state.assessments.filter((x: any) => !where?.userId || x.userId === where.userId).sort((a: any,b: any) => b.createdAt - a.createdAt),
    },
    goal: {
      create: async ({ data }: any) => { const row = { id: id(), status: 'ACTIVE', createdAt: new Date(), updatedAt: new Date(), ...data }; state.goals.push(row); return row; },
      findFirst: async ({ where }: any) => state.goals.find((x: any) => x.id === where.id && x.userId === where.userId && (!where.status || x.status === where.status)) ?? null,
      findMany: async ({ where }: any = {}) => state.goals.filter((x: any) => (!where?.userId || x.userId === where.userId) && (!where?.status || x.status === where.status)),
    },
    action: {
      count: async ({ where }: any) => state.actions.filter((x: any) => x.userId === where.userId && x.goalId === where.goalId && x.status === where.status).length,
      createMany: async ({ data }: any) => { for (const item of data) state.actions.push({ id: id(), status: 'PENDING', createdAt: new Date(), ...item }); return { count: data.length }; },
      findMany: async ({ where }: any) => state.actions.filter((x: any) => (!where?.userId || x.userId === where.userId) && (!where?.goalId || x.goalId === where.goalId) && (!where?.status || x.status === where.status)).sort((a: any,b: any) => a.createdAt - b.createdAt).slice(0, 3),
      findFirst: async ({ where }: any) => state.actions.find((x: any) => x.id === where.id && x.userId === where.userId) ?? null,
      update: async ({ where, data }: any) => { const row = state.actions.find((x: any) => x.id === where.id); Object.assign(row, data); return row; },
    },
    actionResult: {
      create: async ({ data }: any) => { const row = { id: id(), createdAt: new Date(), ...data }; state.results.push(row); return row; },
      findMany: async ({ where }: any) => state.results.filter((x: any) => x.userId === where.userId),
    },
    checkin: { findMany: async ({ where }: any) => state.checkins.filter((x: any) => x.userId === where.userId) },
    aiMemory: { findMany: async ({ where }: any) => state.memories.filter((x: any) => x.userId === where.userId) },
    insight: {
      deleteMany: async ({ where }: any) => { state.insights = state.insights.filter((x: any) => !(x.userId === where.userId && x.dismissed === false && where.type.in.includes(x.type))); },
      create: async ({ data }: any) => { const row = { id: id(), dismissed: false, createdAt: new Date(), ...data }; state.insights.push(row); return row; },
      findMany: async ({ where }: any) => state.insights.filter((x: any) => x.userId === where.userId && (!('dismissed' in where) || x.dismissed === where.dismissed)),
    },
    $transaction: async (operation: any) => Array.isArray(operation) ? Promise.all(operation) : operation(db),
  };
  return { db, state };
}

test('end-to-end journey: assessment → life map → goal → micro-actions → results → insights', async () => {
  const { db, state } = makeDb();
  const lifeMap = new LifeMapController(new LifeMapService() as any, db);
  const goals = new GoalsController(db);
  const actions = new ActionsController(db);
  const insights = new InsightsService(db);
  const request = { user: { sub: userId } };

  const assessments = areaIds.map((areaId, index) => ({
    areaId, satisfaction: index === 7 ? 2 : 5, importance: index === 7 ? 9 : 6,
    motivation: 7, capacity: 6,
  }));
  const scoredMap = await lifeMap.evaluate({ assessments }, request);
  assert.equal(state.assessments.length, 10, 'all ten areas should be persisted');
  assert.equal(scoredMap.length, 10, 'the map should return all ten scored areas');
  assert.ok(scoredMap.every((area: any) => typeof area.dominoScore === 'number'));

  const goal = await goals.create(request, {
    title: 'Criar uma rotina de bem-estar', goalType: 'PROCESS', lifeAreaId: 'HEALTH_ENERGY',
    motivation: 7, importance: 8,
  } as any);
  const planned = await goals.generatePlan(request, goal.id);
  assert.equal(planned.length, 3, 'a new active goal should produce three starter actions');
  assert.ok(planned.every((action: any) => action.status === 'PENDING'));

  for (const action of planned) {
    await actions.complete(request, action.id, {
      completion: 'COMPLETED', difficulty: 3, benefit: 8, moodBefore: 4, moodAfter: 7,
      energyBefore: 4, energyAfter: 6,
    } as any);
  }
  assert.equal(state.results.length, 3, 'each completed action should have one result');
  assert.ok(state.actions.every((action: any) => action.status === 'COMPLETED'));

  const generatedInsights = await insights.refresh(userId);
  assert.ok(generatedInsights.some((item: any) => item.type === 'CONSISTENCY'));
  assert.ok(generatedInsights.some((item: any) => item.type === 'ACTION_EFFECT'));
  assert.ok(generatedInsights.some((item: any) => item.type === 'PRIORITY'));
  assert.ok(state.insights.every((item: any) => item.userId === userId));
});
