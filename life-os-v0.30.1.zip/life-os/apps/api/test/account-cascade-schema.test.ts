import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const rootUrl = new URL('../../../', import.meta.url);
const schemaSql = readFileSync(new URL('db/schema.sql', rootUrl), 'utf8').toLowerCase();
const migrationSql = readFileSync(new URL('db/migrations/20261009_account_deletion_cascade.sql', rootUrl), 'utf8').toLowerCase();
const prismaSchema = readFileSync(new URL('apps/api/prisma/schema.prisma', rootUrl), 'utf8');

test('fresh-install SQL cascades user-owned records on account deletion', () => {
  for (const table of ['life_area_assessments', 'goals', 'actions', 'checkins', 'ai_memories', 'insights', 'action_results']) {
    const start = schemaSql.indexOf(`create table if not exists ${table}`);
    assert.notEqual(start, -1, `missing table ${table}`);
    const end = schemaSql.indexOf('\n);', start);
    const block = schemaSql.slice(start, end);
    assert.match(block, /user_id uuid not null references users\(id\) on delete cascade/, `${table} must cascade on user deletion`);
  }
  assert.match(schemaSql, /goal_id uuid references goals\(id\) on delete set null/);
  assert.match(schemaSql, /action_id uuid not null references actions\(id\) on delete cascade/);
});

test('upgrade migration repairs account and goal/action foreign-key deletion rules', () => {
  for (const table of ['life_area_assessments', 'goals', 'actions', 'checkins', 'ai_memories', 'insights', 'action_results']) {
    assert.match(migrationSql, new RegExp(`alter table ${table} drop constraint if exists`));
    assert.match(migrationSql, new RegExp(`foreign key \\(user_id\\) references users\\(id\\) on delete cascade`));
  }
  assert.match(migrationSql, /foreign key \(goal_id\) references goals\(id\) on delete set null/);
  assert.match(migrationSql, /foreign key \(action_id\) references actions\(id\) on delete cascade/);
});

test('Prisma models account-owned action results with an explicit cascade relation', () => {
  assert.match(prismaSchema, /actionResults ActionResult\[\]/);
  assert.match(prismaSchema, /user User @relation\(fields:\[userId\], references:\[id\], onDelete:Cascade\)/);
});
