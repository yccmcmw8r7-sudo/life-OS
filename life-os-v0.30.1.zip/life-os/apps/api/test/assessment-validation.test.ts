import test from 'node:test';
import assert from 'node:assert/strict';
import { validateAssessments, validateDominoMatrix } from '../src/common/validation.js';
import { LifeMapController } from '../src/life-map/life-map.controller.js';

const areaIds = ['RELATIONSHIPS','FAMILY_FRIENDS','EMOTIONAL_WELLBEING','HEALTH_ENERGY','FINANCES','CAREER','AUTONOMY','PURPOSE','PLEASURE','GROWTH'];
const validAssessments = () => areaIds.map(areaId => ({ areaId, satisfaction: 5, importance: 6, motivation: 7, capacity: 4 }));

test('assessment validator requires all ten distinct known areas', () => {
  assert.equal(validateAssessments(validAssessments()).length, 10);
  assert.throws(() => validateAssessments(validAssessments().slice(1)), /10 avaliações/);
  const duplicate = validAssessments(); duplicate[9].areaId = duplicate[0].areaId;
  assert.throws(() => validateAssessments(duplicate), /inválida ou repetida/);
});

test('assessment validator rejects NaN, Infinity and out-of-range ratings', () => {
  for (const value of [Number.NaN, Number.POSITIVE_INFINITY, -0.1, 10.1, '5']) {
    const data = validAssessments(); (data[0] as any).satisfaction = value;
    assert.throws(() => validateAssessments(data), /Valor inválido/);
  }
});

test('matrix validator accepts valid weights and defaults omitted matrix to empty', () => {
  assert.deepEqual(validateDominoMatrix(undefined), {});
  assert.deepEqual(validateDominoMatrix({ HEALTH_ENERGY: { PURPOSE: 4 } }), { HEALTH_ENERGY: { PURPOSE: 4 } });
});

test('matrix validator rejects unknown areas, self-influence and invalid weights', () => {
  assert.throws(() => validateDominoMatrix({ UNKNOWN: {} }), /Área inválida/);
  assert.throws(() => validateDominoMatrix({ PURPOSE: { PURPOSE: 2 } }), /própria área/);
  for (const weight of [Number.NaN, Number.POSITIVE_INFINITY, -1, 5.1, '2']) {
    assert.throws(() => validateDominoMatrix({ PURPOSE: { HEALTH_ENERGY: weight as any } }), /pesos da matriz/);
  }
});

test('invalid matrix is rejected before any assessment is persisted', async () => {
  let writes = 0;
  const db = { $transaction: async (queries: any[]) => { writes += queries.length; return queries; } };
  const controller = new LifeMapController({ evaluate: () => [] } as any, db as any);
  await assert.rejects(() => controller.evaluate({ assessments: validAssessments(), matrix: { PURPOSE: { PURPOSE: 5 } } }, { user: { sub: 'user-a' } }), /Bad Request/);
  assert.equal(writes, 0);
});
