import test from 'node:test';
import assert from 'node:assert/strict';
import { ServiceUnavailableException } from '@nestjs/common';
import { HealthController } from '../src/health/health.controller.js';

test('liveness does not depend on database availability', () => {
  const controller = new HealthController({ $queryRaw: async () => { throw new Error('database down'); } } as any);
  assert.deepEqual(controller.live(), { status: 'ok' });
});

test('readiness returns healthy only when the database probe succeeds', async () => {
  let queried = false;
  const controller = new HealthController({ $queryRaw: async () => { queried = true; return [{ '?column?': 1 }]; } } as any);
  assert.deepEqual(await controller.ready(), { status: 'ok', checks: { database: 'ok' } });
  assert.equal(queried, true);
});

test('readiness returns a sanitized 503 when the database probe fails', async () => {
  const controller = new HealthController({ $queryRaw: async () => { throw new Error('postgres://secret-user:secret-pass@db/private'); } } as any);
  await assert.rejects(controller.ready(), (error: unknown) => {
    assert.ok(error instanceof ServiceUnavailableException);
    assert.equal(error.getStatus(), 503);
    assert.deepEqual(error.getResponse(), { status: 'error', checks: { database: 'unavailable' } });
    assert.equal(JSON.stringify(error.getResponse()).includes('secret-pass'), false);
    return true;
  });
});
