import test, { afterEach } from 'node:test';
import assert from 'node:assert/strict';
import jwt from 'jsonwebtoken';
import { UnauthorizedException } from '@nestjs/common';
import { AuthGuard } from '../src/auth/auth.guard.js';

const SECRET = 'test-secret-with-at-least-32-characters';
const originalSecret = process.env.JWT_SECRET;
afterEach(() => {
  if (originalSecret === undefined) delete process.env.JWT_SECRET;
  else process.env.JWT_SECRET = originalSecret;
});
function context(authorization?: string) {
  const request: any = { headers: {} };
  if (authorization !== undefined) request.headers.authorization = authorization;
  return {
    request,
    executionContext: {
      switchToHttp: () => ({ getRequest: () => request }),
    } as any,
  };
}

test('auth guard rejects missing and non-Bearer authorization headers', () => {
  process.env.JWT_SECRET = SECRET;
  const guard = new AuthGuard();
  for (const header of [undefined, '', 'Basic abc', 'bearer abc']) {
    const { executionContext } = context(header);
    assert.throws(() => guard.canActivate(executionContext), UnauthorizedException);
  }
});

test('auth guard rejects malformed, expired and incorrectly signed tokens', () => {
  process.env.JWT_SECRET = SECRET;
  const guard = new AuthGuard();
  const expired = jwt.sign({ sub: 'user-a' }, SECRET, { expiresIn: -1 });
  const wrongSecret = jwt.sign({ sub: 'user-a' }, 'different-secret-that-is-long-enough');
  for (const token of ['not-a-token', expired, wrongSecret]) {
    const { executionContext } = context(`Bearer ${token}`);
    assert.throws(() => guard.canActivate(executionContext), UnauthorizedException);
  }
});

test('auth guard attaches verified claims to the request', () => {
  process.env.JWT_SECRET = SECRET;
  const token = jwt.sign({ sub: 'user-a', email: 'a@example.com' }, SECRET);
  const { executionContext, request } = context(`Bearer ${token}`);
  assert.equal(new AuthGuard().canActivate(executionContext), true);
  assert.equal(request.user.sub, 'user-a');
  assert.equal(request.user.email, 'a@example.com');
});

test('auth guard fails closed when JWT_SECRET is absent', () => {
  const previous = process.env.JWT_SECRET;
  delete process.env.JWT_SECRET;
  try {
    const token = jwt.sign({ sub: 'user-a' }, SECRET);
    const { executionContext } = context(`Bearer ${token}`);
    assert.throws(() => new AuthGuard().canActivate(executionContext), UnauthorizedException);
  } finally {
    if (previous === undefined) delete process.env.JWT_SECRET;
    else process.env.JWT_SECRET = previous;
  }
});
