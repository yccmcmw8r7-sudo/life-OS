import test from 'node:test';
import assert from 'node:assert/strict';
import { GoalsController } from '../src/goals/goals.controller.js';
import { NotFoundException, BadRequestException } from '@nestjs/common';

test('goal plan only proceeds for an active goal owned by the authenticated user', async () => {
  let query: any;
  const db = { goal: { findFirst: async (q: any) => { query = q; return null; } } };
  const controller = new GoalsController(db as any);
  await assert.rejects(() => controller.generatePlan({ user: { sub: 'user-a' } }, 'goal-b'), NotFoundException);
  assert.deepEqual(query.where, { id: 'goal-b', userId: 'user-a', status: 'ACTIVE' });
});

test('goal creation rejects blank titles', async () => {
  const db = { goal: { create: async () => { throw new Error('should not persist'); } } };
  const controller = new GoalsController(db as any);
  await assert.rejects(() => controller.create({ user: { sub: 'user-a' } }, { title: '   ', goalType: 'PROCESS' }), BadRequestException);
});
