import test from 'node:test';
import assert from 'node:assert/strict';
import { isAllowedBrowserOrigin } from '../src/common/cors-policy.js';

test('CORS permits native requests without Origin and explicitly allowed browser origins only', () => {
  const allowed = new Set(['https://lifeos.example', 'http://localhost:8081']);
  assert.equal(isAllowedBrowserOrigin(undefined, allowed), true);
  assert.equal(isAllowedBrowserOrigin('https://lifeos.example', allowed), true);
  assert.equal(isAllowedBrowserOrigin('http://localhost:8081', allowed), true);
  assert.equal(isAllowedBrowserOrigin('https://untrusted.example', allowed), false);
  assert.equal(isAllowedBrowserOrigin('null', allowed), false);
});
