import test from 'node:test';
import assert from 'node:assert/strict';
import { MemoriesController } from '../src/memories/memories.controller.js';
import { NotFoundException, BadRequestException } from '@nestjs/common';

test('memory listing is always scoped to the authenticated user and active memories', async () => {
  let query: any;
  const db = { aiMemory: { findMany: async (q: any) => { query = q; return []; } } };
  const controller = new MemoriesController(db as any);
  await controller.list({ user: { sub: 'user-a' } });
  assert.deepEqual(query.where, { userId: 'user-a', active: true });
});

test('a user cannot update another user memory', async () => {
  let query: any;
  const db = { aiMemory: { findFirst: async (q: any) => { query = q; return null; } } };
  const controller = new MemoriesController(db as any);
  await assert.rejects(() => controller.update({ user: { sub: 'user-a' } }, 'memory-b', { content: 'new text' }), NotFoundException);
  assert.deepEqual(query.where, { id: 'memory-b', userId: 'user-a', active: true });
});

test('memory creation requires explicit consent and bounded content', async () => {
  const db = { aiMemory: { create: async () => { throw new Error('should not persist'); } } };
  const controller = new MemoriesController(db as any);
  await assert.rejects(() => controller.create({ user: { sub: 'user-a' } }, { consent: false, category: 'preference', content: 'some text' }), BadRequestException);
});
