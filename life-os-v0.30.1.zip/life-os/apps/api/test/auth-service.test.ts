import test from 'node:test';
import assert from 'node:assert/strict';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { ConflictException, UnauthorizedException } from '@nestjs/common';
import { AuthService } from '../src/auth/auth.service.js';

const SECRET = 'test-secret-with-at-least-32-characters';

test('registration normalizes email, stores only a password hash and returns a verifiable token', async () => {
  const previous = process.env.JWT_SECRET;
  process.env.JWT_SECRET = SECRET;
  const calls: any[] = [];
  const db = {
    user: {
      findUnique: async (query: any) => { calls.push(['findUnique', query]); return null; },
      create: async (query: any) => { calls.push(['create', query]); return { id: 'user-a', email: query.data.email, name: query.data.name }; },
    },
  };
  try {
    const result = await new AuthService(db as any).register(' PERSON@EXAMPLE.COM ', 'correct-horse-battery', 'Pessoa');
    assert.equal(calls[0][1].where.email, 'person@example.com');
    assert.equal(calls[1][1].data.email, 'person@example.com');
    assert.notEqual(calls[1][1].data.passwordHash, 'correct-horse-battery');
    assert.equal(await bcrypt.compare('correct-horse-battery', calls[1][1].data.passwordHash), true);
    assert.equal(result.user.id, 'user-a');
    assert.equal((jwt.verify(result.accessToken, SECRET) as any).sub, 'user-a');
    assert.equal(JSON.stringify(result).includes('passwordHash'), false);
  } finally {
    if (previous === undefined) delete process.env.JWT_SECRET;
    else process.env.JWT_SECRET = previous;
  }
});

test('registration rejects an existing email before creating a user', async () => {
  let creates = 0;
  const db = { user: {
    findUnique: async () => ({ id: 'existing', email: 'person@example.com' }),
    create: async () => { creates += 1; throw new Error('must not create'); },
  } };
  await assert.rejects(() => new AuthService(db as any).register('person@example.com', 'correct-horse-battery'), ConflictException);
  assert.equal(creates, 0);
});

test('login rejects unknown users and incorrect passwords with the same public error', async () => {
  const dbUnknown = { user: { findUnique: async () => null } };
  await assert.rejects(() => new AuthService(dbUnknown as any).login('unknown@example.com', 'incorrect-password'), UnauthorizedException);
  const hash = await bcrypt.hash('correct-horse-battery', 4);
  const dbKnown = { user: { findUnique: async () => ({ id: 'user-a', email: 'person@example.com', name: null, passwordHash: hash }) } };
  await assert.rejects(() => new AuthService(dbKnown as any).login('person@example.com', 'incorrect-password'), UnauthorizedException);
});

test('login accepts a valid password and returns user data without password hash', async () => {
  const previous = process.env.JWT_SECRET;
  process.env.JWT_SECRET = SECRET;
  const hash = await bcrypt.hash('correct-horse-battery', 4);
  const db = { user: { findUnique: async (query: any) => {
    assert.equal(query.where.email, 'person@example.com');
    return { id: 'user-a', email: 'person@example.com', name: 'Pessoa', passwordHash: hash };
  } } };
  try {
    const result = await new AuthService(db as any).login('PERSON@EXAMPLE.COM', 'correct-horse-battery');
    assert.equal(result.user.email, 'person@example.com');
    assert.equal((jwt.verify(result.accessToken, SECRET) as any).sub, 'user-a');
    assert.equal(JSON.stringify(result).includes(hash), false);
  } finally {
    if (previous === undefined) delete process.env.JWT_SECRET;
    else process.env.JWT_SECRET = previous;
  }
});
