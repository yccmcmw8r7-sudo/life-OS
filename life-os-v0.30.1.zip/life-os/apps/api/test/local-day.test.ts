import test from 'node:test';
import assert from 'node:assert/strict';
import { getLocalDayBounds, safeTimeZone } from '../src/common/local-day.js';

test('returns the Lisbon calendar date and a normal 24-hour day', () => {
  const bounds = getLocalDayBounds(new Date('2026-02-10T12:00:00.000Z'), 'Europe/Lisbon');
  assert.equal(bounds.date, '2026-02-10');
  assert.equal(bounds.start.toISOString(), '2026-02-10T00:00:00.000Z');
  assert.equal(bounds.end.toISOString(), '2026-02-11T00:00:00.000Z');
});

test('handles the spring daylight-saving transition (23-hour day)', () => {
  const bounds = getLocalDayBounds(new Date('2026-03-29T12:00:00.000Z'), 'Europe/Lisbon');
  assert.equal(bounds.date, '2026-03-29');
  assert.equal(bounds.start.toISOString(), '2026-03-29T00:00:00.000Z');
  assert.equal(bounds.end.toISOString(), '2026-03-29T23:00:00.000Z');
  assert.equal((bounds.end.getTime() - bounds.start.getTime()) / 3_600_000, 23);
});

test('handles the autumn daylight-saving transition (25-hour day)', () => {
  const bounds = getLocalDayBounds(new Date('2026-10-25T12:00:00.000Z'), 'Europe/Lisbon');
  assert.equal(bounds.date, '2026-10-25');
  assert.equal(bounds.start.toISOString(), '2026-10-24T23:00:00.000Z');
  assert.equal(bounds.end.toISOString(), '2026-10-26T00:00:00.000Z');
  assert.equal((bounds.end.getTime() - bounds.start.getTime()) / 3_600_000, 25);
});

test('rejects an invalid time-zone identifier at the strict calendar helper boundary', () => {
  assert.throws(() => getLocalDayBounds(new Date(), 'Not/A_Timezone'), RangeError);
});

test('uses a safe fallback for invalid or missing profile time zones', () => {
  assert.equal(safeTimeZone('Not/A_Timezone'), 'Europe/Lisbon');
  assert.equal(safeTimeZone(undefined), 'Europe/Lisbon');
  assert.equal(safeTimeZone('America/New_York'), 'America/New_York');
});
