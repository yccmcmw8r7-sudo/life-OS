import { Body, Controller, Post } from '@nestjs/common';
import { IsEmail, IsOptional, IsString, MinLength } from 'class-validator';
import { AuthService } from './auth.service.js';
class RegisterDto { @IsEmail() email!:string; @IsString() @MinLength(8) password!:string; @IsOptional() @IsString() name?:string; }
class LoginDto { @IsEmail() email!:string; @IsString() @MinLength(8) password!:string; }
@Controller('auth') export class AuthController { constructor(private auth:AuthService){} @Post('register') register(@Body() d:RegisterDto){return this.auth.register(d.email,d.password,d.name)} @Post('login') login(@Body() d:LoginDto){return this.auth.login(d.email,d.password)} }
