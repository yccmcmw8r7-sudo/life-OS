import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import jwt from 'jsonwebtoken';
@Injectable() export class AuthGuard implements CanActivate {
  canActivate(context:ExecutionContext){
    const req=context.switchToHttp().getRequest(); const header=req.headers.authorization as string|undefined;
    if(!header?.startsWith('Bearer ')) throw new UnauthorizedException('Autenticação necessária.');
    try{ const secret=process.env.JWT_SECRET; if(!secret) throw new Error(); req.user=jwt.verify(header.slice(7),secret); return true; } catch { throw new UnauthorizedException('Sessão inválida ou expirada.'); }
  }
}
