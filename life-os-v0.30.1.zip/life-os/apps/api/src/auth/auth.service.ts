import { Injectable, UnauthorizedException, ConflictException } from '@nestjs/common';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { PrismaService } from '../common/prisma.service.js';
@Injectable()
export class AuthService {
  constructor(private db: PrismaService) {}
  async register(email:string,password:string,name?:string){
    const existing=await this.db.user.findUnique({where:{email:email.trim().toLowerCase()}});
    if(existing) throw new ConflictException('Este email já está registado.');
    const passwordHash=await bcrypt.hash(password,12);
    const user=await this.db.user.create({data:{email:email.trim().toLowerCase(),passwordHash,name}});
    return this.issue(user.id,user.email,user.name);
  }
  async login(email:string,password:string){
    const user=await this.db.user.findUnique({where:{email:email.trim().toLowerCase()}});
    if(!user || !(await bcrypt.compare(password,user.passwordHash))) throw new UnauthorizedException('Email ou palavra-passe inválidos.');
    return this.issue(user.id,user.email,user.name);
  }
  private issue(id:string,email:string,name:string|null){
    const secret=process.env.JWT_SECRET;
    if(!secret) throw new Error('JWT_SECRET não configurado.');
    return {accessToken:jwt.sign({sub:id,email},secret,{expiresIn:'7d'}),user:{id,email,name}};
  }
}
