import {Injectable} from '@nestjs/common';
import {Assessment,DominoMatrix,applyDomino,scoreAssessment} from '@life-os/scoring';
@Injectable()
export class LifeMapService {
  evaluate(assessments:Assessment[], matrix:DominoMatrix={}) {
    return applyDomino(assessments.map(scoreAssessment),matrix).sort((a,b)=>b.dominoScore-a.dominoScore);
  }
}
