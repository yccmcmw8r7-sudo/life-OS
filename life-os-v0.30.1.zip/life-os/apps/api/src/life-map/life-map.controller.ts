import {Body,Controller,Post,Get,BadRequestException,Req,UseGuards} from '@nestjs/common';
import {LifeMapService} from './life-map.service.js';
import {validateAssessments, validateDominoMatrix} from '../common/validation.js';
import {PrismaService} from '../common/prisma.service.js';
import {AuthGuard} from '../auth/auth.guard.js';
import {Assessment, LifeAreaId, applyDomino, scoreAssessment} from '@life-os/scoring';
@Controller('life-map')
export class LifeMapController {
 constructor(private readonly service:LifeMapService, private readonly db:PrismaService){}
 @Get('latest') @UseGuards(AuthGuard) async latest(@Req() req:any){
  const records=await this.db.lifeAreaAssessment.findMany({where:{userId:req.user.sub},orderBy:{createdAt:'desc'},distinct:['areaId']});
  if(!records.length) return [];
  const assessments:Assessment[]=records.map((a:any)=>({areaId:a.areaId as LifeAreaId,satisfaction:a.satisfaction,importance:a.importance,motivation:a.motivation,capacity:a.capacity}));
  return applyDomino(assessments.map(scoreAssessment),{}).sort((a,b)=>b.dominoScore-a.dominoScore);
 }
 @Post('evaluate') @UseGuards(AuthGuard) async evaluate(@Body() body:unknown,@Req() req:any){
  let assessments:any[]; let matrix;
  try {
   assessments=validateAssessments((body as any)?.assessments);
   matrix=validateDominoMatrix((body as any)?.matrix);
  } catch (e) {
   throw new BadRequestException(e instanceof Error ? e.message : 'Dados inválidos.');
  }
  await this.db.$transaction(assessments.map((a:any)=>this.db.lifeAreaAssessment.create({data:{userId:req.user.sub,areaId:a.areaId,satisfaction:a.satisfaction,importance:a.importance,motivation:a.motivation,capacity:a.capacity}})));
  return this.service.evaluate(assessments,matrix);
 }
}
