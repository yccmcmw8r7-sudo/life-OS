import { Body, Controller, Delete, Get, Param, Patch, Post, Req, UseGuards, BadRequestException, NotFoundException } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard.js';
import { PrismaService } from '../common/prisma.service.js';

@Controller('memories')
@UseGuards(AuthGuard)
export class MemoriesController {
  constructor(private readonly db: PrismaService) {}
  @Get() async list(@Req() req: any) {
    return this.db.aiMemory.findMany({ where: { userId: req.user.sub, active: true }, select: { id: true, category: true, content: true, confidence: true, source: true, userConfirmed: true, createdAt: true, updatedAt: true }, orderBy: { updatedAt: 'desc' } });
  }
  @Post() async create(@Req() req: any, @Body() body: any) {
    const category = typeof body.category === 'string' ? body.category.trim() : '';
    const content = typeof body.content === 'string' ? body.content.trim() : '';
    if (!body.consent || !category || category.length > 60 || !content || content.length > 500) throw new BadRequestException('É necessário consentimento explícito e conteúdo válido (máximo 500 caracteres).');
    return this.db.aiMemory.create({ data: { userId: req.user.sub, category, content, source: 'user-provided', confidence: 1, userConfirmed: true }, select: { id: true, category: true, content: true, confidence: true, source: true, userConfirmed: true, createdAt: true } });
  }
  @Patch(':id') async update(@Req() req: any, @Param('id') id: string, @Body() body: any) {
    const existing = await this.db.aiMemory.findFirst({ where: { id, userId: req.user.sub, active: true } });
    if (!existing) throw new NotFoundException('Memória não encontrada.');
    const data: any = {};
    if (typeof body.content === 'string') { const content = body.content.trim(); if (!content || content.length > 500) throw new BadRequestException('O conteúdo deve ter entre 1 e 500 caracteres.'); data.content = content; data.userConfirmed = body.confirmed === true; }
    if (typeof body.category === 'string') { const category = body.category.trim(); if (!category || category.length > 60) throw new BadRequestException('Categoria inválida.'); data.category = category; }
    return this.db.aiMemory.update({ where: { id }, data, select: { id: true, category: true, content: true, confidence: true, source: true, userConfirmed: true, updatedAt: true } });
  }
  @Delete(':id') async remove(@Req() req: any, @Param('id') id: string) {
    const existing = await this.db.aiMemory.findFirst({ where: { id, userId: req.user.sub, active: true } });
    if (!existing) throw new NotFoundException('Memória não encontrada.');
    await this.db.aiMemory.update({ where: { id }, data: { active: false } });
    return { success: true };
  }
}
