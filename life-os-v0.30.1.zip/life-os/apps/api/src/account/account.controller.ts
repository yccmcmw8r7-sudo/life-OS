import { BadRequestException, Body, Controller, Delete, Get, Header, UnauthorizedException, UseGuards, Req } from '@nestjs/common';
import { IsEmail, IsString, MinLength } from 'class-validator';
import bcrypt from 'bcryptjs';
import { AuthGuard } from '../auth/auth.guard.js';
import { PrismaService } from '../common/prisma.service.js';

class DeleteAccountDto {
  @IsEmail() email!: string;
  @IsString() @MinLength(8) password!: string;
  @IsString() confirmation!: string;
}

@Controller('account')
@UseGuards(AuthGuard)
export class AccountController {
  constructor(private readonly db: PrismaService) {}

  /** Returns only data belonging to the authenticated user and never includes credentials. */
  @Get('export')
  @Header('Cache-Control', 'no-store, private')
  @Header('Pragma', 'no-cache')
  async exportData(@Req() req: any) {
    const userId = req.user.sub as string;
    const user = await this.db.user.findUnique({
      where: { id: userId },
      select: { id: true, email: true, name: true, timezone: true, language: true, createdAt: true, updatedAt: true },
    });
    if (!user) throw new UnauthorizedException('Conta não encontrada.');
    const [assessments, goals, actions, actionResults, checkins, memories, insights] = await Promise.all([
      this.db.lifeAreaAssessment.findMany({ where: { userId }, orderBy: { createdAt: 'asc' } }),
      this.db.goal.findMany({ where: { userId }, orderBy: { createdAt: 'asc' } }),
      this.db.action.findMany({ where: { userId }, orderBy: { createdAt: 'asc' } }),
      this.db.actionResult.findMany({ where: { userId }, orderBy: { createdAt: 'asc' } }),
      this.db.checkin.findMany({ where: { userId }, orderBy: { createdAt: 'asc' } }),
      this.db.aiMemory.findMany({ where: { userId }, orderBy: { createdAt: 'asc' } }),
      this.db.insight.findMany({ where: { userId }, orderBy: { createdAt: 'asc' } }),
    ]);
    return { format: 'life-os-export', version: 1, exportedAt: new Date().toISOString(), user,
      data: { assessments, goals, actions, actionResults, checkins, memories, insights } };
  }

  /** Requires the current password, matching email, and an explicit destructive confirmation. */
  @Delete()
  async deleteAccount(@Req() req: any, @Body() body: DeleteAccountDto) {
    if (body.confirmation !== 'DELETE MY ACCOUNT') {
      throw new BadRequestException('Para confirmar, escreve DELETE MY ACCOUNT.');
    }
    const userId = req.user.sub as string;
    const user = await this.db.user.findUnique({ where: { id: userId } });
    if (!user) throw new UnauthorizedException('Conta não encontrada.');
    if (user.email.toLowerCase() !== body.email.trim().toLowerCase() || !(await bcrypt.compare(body.password, user.passwordHash))) {
      throw new UnauthorizedException('Email ou palavra-passe inválidos.');
    }
    // User-owned rows use database cascade constraints. Deletion is permanent.
    await this.db.user.delete({ where: { id: userId } });
    return { success: true, deleted: true };
  }
}
