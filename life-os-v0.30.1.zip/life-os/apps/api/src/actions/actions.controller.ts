import { Body, Controller, Get, Param, Patch, Post, Req, UseGuards, BadRequestException, NotFoundException, ConflictException } from '@nestjs/common';
import { IsInt, IsIn, IsOptional, IsString, Max, Min, MaxLength, IsISO8601 } from 'class-validator';
import { PrismaService } from '../common/prisma.service.js';
import { AuthGuard } from '../auth/auth.guard.js';
import { getLocalDayBounds, safeTimeZone } from '../common/local-day.js';

const AREA_IDS = new Set(['RELATIONSHIPS','FAMILY_FRIENDS','EMOTIONAL_WELLBEING','HEALTH_ENERGY','FINANCES','CAREER','AUTONOMY','PURPOSE','PLEASURE','GROWTH']);
class CreateActionDto {
  @IsString() @MaxLength(160) title!: string;
  @IsOptional() @IsString() @MaxLength(2000) description?: string;
  @IsOptional() @IsString() goalId?: string;
  @IsOptional() @IsString() lifeAreaId?: string;
  @IsOptional() @IsInt() @Min(1) @Max(1440) estimatedMinutes?: number;
  @IsOptional() @IsInt() @Min(0) @Max(10) expectedImpact?: number;
  @IsOptional() @IsInt() @Min(0) @Max(10) confidence?: number;
  @IsOptional() @IsInt() @Min(0) @Max(10) effort?: number;
  @IsOptional() @IsInt() @Min(0) @Max(10) complexity?: number;
  @IsOptional() @IsISO8601() scheduledDate?: string;
}
class ResultDto {
  @IsIn(['COMPLETED','PARTIAL','SKIPPED']) completion!: 'COMPLETED'|'PARTIAL'|'SKIPPED';
  @IsOptional() @IsInt() @Min(0) @Max(10) difficulty?: number;
  @IsOptional() @IsInt() @Min(0) @Max(10) benefit?: number;
  @IsOptional() @IsInt() @Min(0) @Max(10) moodBefore?: number;
  @IsOptional() @IsInt() @Min(0) @Max(10) moodAfter?: number;
  @IsOptional() @IsInt() @Min(0) @Max(10) energyBefore?: number;
  @IsOptional() @IsInt() @Min(0) @Max(10) energyAfter?: number;
  @IsOptional() @IsString() @MaxLength(2000) notes?: string;
}

@Controller('actions')
@UseGuards(AuthGuard)
export class ActionsController {
  constructor(private db: PrismaService) {}

  @Get('today')
  async today(@Req() req: any) {
    const user = await this.db.user.findUnique({ where: { id: req.user.sub }, select: { timezone: true } });
    const { start, end } = getLocalDayBounds(new Date(), safeTimeZone(user?.timezone));
    return this.db.action.findMany({ where: { userId: req.user.sub, status: 'PENDING', OR: [{ scheduledDate: null }, { scheduledDate: { gte: start, lt: end } }] }, orderBy: { priorityScore: 'desc' }, take: 3, include: { goal: true } });
  }

  @Post()
  async create(@Req() req: any, @Body() data: CreateActionDto) {
    const userId = req.user.sub;
    if (!data.title.trim()) throw new BadRequestException('O título não pode ficar vazio.');
    if (data.lifeAreaId && !AREA_IDS.has(data.lifeAreaId)) throw new BadRequestException('Área de vida inválida.');
    if (data.goalId) {
      const goal = await this.db.goal.findFirst({ where: { id: data.goalId, userId, status: 'ACTIVE' }, select: { id: true, lifeAreaId: true } });
      if (!goal) throw new NotFoundException('Objetivo ativo não encontrado.');
      if (data.lifeAreaId && goal.lifeAreaId && data.lifeAreaId !== goal.lifeAreaId) throw new BadRequestException('A área da ação deve corresponder à área do objetivo.');
    }
    return this.db.action.create({ data: { userId, title: data.title.trim(), description: data.description?.trim(), goalId: data.goalId, lifeAreaId: data.lifeAreaId, estimatedMinutes: data.estimatedMinutes, expectedImpact: data.expectedImpact, confidence: data.confidence, effort: data.effort, complexity: data.complexity, scheduledDate: data.scheduledDate ? new Date(data.scheduledDate) : undefined } });
  }

  @Patch(':id/complete')
  complete(@Req() req: any, @Param('id') id: string, @Body() data: ResultDto) {
    return this.db.$transaction(async tx => {
      const action = await tx.action.findFirst({ where: { id, userId: req.user.sub } });
      if (!action) throw new NotFoundException('Ação não encontrada.');
      if (action.status !== 'PENDING') throw new ConflictException('Esta ação já não está pendente. Atualiza a lista antes de continuar.');
      const result = await tx.actionResult.create({ data: { actionId: id, userId: req.user.sub, ...data } });
      await tx.action.update({ where: { id }, data: { status: data.completion === 'COMPLETED' ? 'COMPLETED' : data.completion === 'SKIPPED' ? 'SKIPPED' : 'PENDING' } });
      return result;
    });
  }
}
