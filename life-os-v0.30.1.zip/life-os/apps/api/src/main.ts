import 'reflect-metadata';
import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module.js';
import { isAllowedBrowserOrigin } from './common/cors-policy.js';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  // Native iOS/Android clients normally send no Origin header. Browser clients
  // must be explicitly allow-listed through CORS_ORIGINS in production.
  const allowedOrigins = new Set(
    (process.env.CORS_ORIGINS ?? '')
      .split(',')
      .map((origin) => origin.trim())
      .filter(Boolean),
  );
  app.enableCors({
    origin: (origin, callback) => {
      return callback(null, isAllowedBrowserOrigin(origin, allowedOrigins));
    },
    credentials: false,
  });
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true, forbidNonWhitelisted: true }));
  await app.listen(Number(process.env.PORT ?? 3000));
  console.log(`LIFE OS API listening on ${process.env.PORT ?? 3000}`);
}

void bootstrap();
