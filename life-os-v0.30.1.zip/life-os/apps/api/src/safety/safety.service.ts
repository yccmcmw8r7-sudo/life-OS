import {Injectable} from '@nestjs/common';
export type RiskLevel='SAFE'|'CAUTION'|'HIGH_RISK';
export type SafetyResult={level:RiskLevel;reason?:string};
@Injectable()
export class SafetyService {
 classify(text:string):SafetyResult {
  const t=text.toLowerCase();
  const high=['suicídio','suicidio','matar-me','matar me','autoagress','não quero viver','nao quero viver'];
  if(high.some(x=>t.includes(x))) return {level:'HIGH_RISK',reason:'possible self-harm signal'};
  const caution=['pânico','panico','depressão','depressao','ansiedade extrema','abuso','violência','violencia'];
  if(caution.some(x=>t.includes(x))) return {level:'CAUTION',reason:'sensitive wellbeing signal'};
  return {level:'SAFE'};
 }
}
