import {Body,Controller,Post} from '@nestjs/common'; import {SafetyService} from './safety.service.js';
@Controller('safety') export class SafetyController {constructor(private readonly safety:SafetyService){} @Post('classify') classify(@Body() body:{text?:string}){return this.safety.classify(body?.text??'');}}
