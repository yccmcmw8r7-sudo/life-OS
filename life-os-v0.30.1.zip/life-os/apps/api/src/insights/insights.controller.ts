import { Controller, Get, Post, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard.js';
import { InsightsService } from './insights.service.js';

@Controller('insights')
@UseGuards(AuthGuard)
export class InsightsController {
  constructor(private service: InsightsService) {}
  @Get() list(@Req() r: any) { return this.service.list(r.user.sub); }
  @Post('refresh') refresh(@Req() r: any) { return this.service.refresh(r.user.sub); }
}

@Controller('weekly-review')
@UseGuards(AuthGuard)
export class WeeklyReviewController {
  constructor(private service: InsightsService) {}
  @Get() review(@Req() r: any) { return this.service.weeklyReview(r.user.sub); }
}
