import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service.js';

export interface GeneratedInsight {
  type: string;
  title: string;
  description: string;
  confidence: number;
  evidence: Record<string, unknown>;
}

@Injectable()
export class InsightsService {
  constructor(private db: PrismaService) {}

  private async sourceData(userId: string) {
    const since = new Date();
    since.setDate(since.getDate() - 14);
    const [results, checkins, assessments, goals] = await Promise.all([
      this.db.actionResult.findMany({ where: { userId, createdAt: { gte: since } }, orderBy: { createdAt: 'desc' }, include: { action: true } }),
      this.db.checkin.findMany({ where: { userId, createdAt: { gte: since } }, orderBy: { createdAt: 'desc' } }),
      this.db.lifeAreaAssessment.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take: 100 }),
      this.db.goal.findMany({ where: { userId, status: 'ACTIVE' }, orderBy: { updatedAt: 'desc' }, take: 5 }),
    ]);
    return { results, checkins, assessments, goals };
  }

  private generate(data: Awaited<ReturnType<InsightsService['sourceData']>>): GeneratedInsight[] {
    const { results, checkins, assessments, goals } = data;
    const insights: GeneratedInsight[] = [];
    const sample = results.length;

    if (sample >= 3) {
      const completed = results.filter(r => r.completion === 'COMPLETED').length;
      const partial = results.filter(r => r.completion === 'PARTIAL').length;
      const skipped = results.filter(r => r.completion === 'SKIPPED').length;
      const completionRate = completed / sample;
      const positiveBenefits = results.filter(r => (r.benefit ?? 0) >= 7).length;
      const avgMoodDelta = results.filter(r => r.moodBefore != null && r.moodAfter != null)
        .reduce((sum, r) => sum + ((r.moodAfter ?? 0) - (r.moodBefore ?? 0)), 0) /
        Math.max(1, results.filter(r => r.moodBefore != null && r.moodAfter != null).length);
      const avgEnergyDelta = results.filter(r => r.energyBefore != null && r.energyAfter != null)
        .reduce((sum, r) => sum + ((r.energyAfter ?? 0) - (r.energyBefore ?? 0)), 0) /
        Math.max(1, results.filter(r => r.energyBefore != null && r.energyAfter != null).length);

      if (completionRate >= 0.7) {
        insights.push({
          type: 'CONSISTENCY',
          title: 'Estás a conseguir manter o movimento',
          description: `Nos últimos dias, concluíste ${Math.round(completionRate * 100)}% das ações registadas. Parece existir um padrão de consistência que vale a pena preservar, sem aumentar a pressão só porque está a correr bem.`,
          confidence: Math.min(0.95, 0.55 + sample * 0.05),
          evidence: { sample, completed, completionRate },
        });
      }

      if (positiveBenefits / sample >= 0.5 && (avgMoodDelta > 0.5 || avgEnergyDelta > 0.5)) {
        insights.push({
          type: 'ACTION_EFFECT',
          title: 'Algumas ações parecem estar a fazer-te bem',
          description: `Mais de metade das ações tiveram benefício elevado e os registos disponíveis mostram uma melhoria média no estado após algumas ações. Isto é um sinal útil sobre o que pode funcionar contigo — não uma prova de causalidade.`,
          confidence: Math.min(0.9, 0.45 + sample * 0.06),
          evidence: { sample, positiveBenefits, avgMoodDelta, avgEnergyDelta },
        });
      }

      if ((partial + skipped) / sample >= 0.5) {
        const difficult = results.filter(r => (r.difficulty ?? 0) >= 7).length;
        insights.push({
          type: 'BARRIER',
          title: 'Pode haver demasiada fricção',
          description: `Pelo menos metade das ações recentes ficaram parciais ou foram adiadas. Em vez de aumentar o esforço, faz sentido investigar se o tamanho, o momento ou a dificuldade das ações está desalinhado com a tua capacidade atual.`,
          confidence: Math.min(0.9, 0.5 + sample * 0.05),
          evidence: { sample, partial, skipped, difficult },
        });
      }
    }

    if (checkins.length >= 3) {
      const lowEnergy = checkins.filter(c => (c.energy ?? 10) <= 4).length;
      const highStress = checkins.filter(c => (c.stress ?? 0) >= 7).length;
      if (lowEnergy / checkins.length >= 0.5 || highStress / checkins.length >= 0.5) {
        insights.push({
          type: 'CAPACITY',
          title: 'A tua capacidade parece estar mais baixa',
          description: 'Os teus check-ins recentes mostram energia mais baixa e/ou stress mais elevado com alguma frequência. Pode ser útil reduzir a exigência das próximas ações e proteger espaço para recuperação.',
          confidence: Math.min(0.88, 0.5 + checkins.length * 0.06),
          evidence: { checkins: checkins.length, lowEnergy, highStress },
        });
      }
    }

    const latestByArea = new Map<string, (typeof assessments)[number]>();
    for (const assessment of assessments) {
      if (!latestByArea.has(assessment.areaId)) latestByArea.set(assessment.areaId, assessment);
    }
    const latest = [...latestByArea.values()]
      .sort((a, b) => (b.importance - b.satisfaction) - (a.importance - a.satisfaction))[0];
    if (latest) {
      const gap = latest.importance - latest.satisfaction;
      if (gap >= 5) {
        insights.push({
          type: 'PRIORITY',
          title: 'Há uma área importante com espaço para melhorar',
          description: 'O teu último mapa mostra uma diferença relevante entre a importância que atribuis a esta área e a satisfação atual. Em vez de tentar corrigir tudo, vale a pena escolher um passo pequeno e concreto.',
          confidence: 0.75,
          evidence: { areaId: latest.areaId, gap, importance: latest.importance, satisfaction: latest.satisfaction },
        });
      }
    }

    if (goals.length === 0 && latestByArea.size > 0) {
      insights.push({
        type: 'NEXT_STEP',
        title: 'Ainda não precisas de ter tudo decidido',
        description: 'Não tens objetivos ativos neste momento. Um próximo passo simples pode ser escolher uma área que importe para ti e experimentar uma pequena mudança durante alguns dias.',
        confidence: 0.9,
        evidence: { goals: 0 },
      });
    }

    return insights.slice(0, 6);
  }

  async refresh(userId: string) {
    const data = await this.sourceData(userId);
    const generated = this.generate(data);
    // Refresh generated insight types in-place conceptually: remove stale, non-dismissed
    // snapshots first so repeated refreshes do not inflate the feed with duplicates.
    const generatedTypes = ['CONSISTENCY', 'ACTION_EFFECT', 'BARRIER', 'CAPACITY', 'PRIORITY', 'NEXT_STEP'];
    await this.db.$transaction(async tx => {
      await tx.insight.deleteMany({ where: { userId, dismissed: false, type: { in: generatedTypes } } });
      for (const insight of generated) {
        await tx.insight.create({ data: { userId, type: insight.type, title: insight.title, description: insight.description, confidence: insight.confidence, evidence: insight.evidence } });
      }
    });
    return generated;
  }

  async list(userId: string) {
    const existing = await this.db.insight.findMany({ where: { userId, dismissed: false }, orderBy: { createdAt: 'desc' }, take: 12 });
    if (existing.length) return existing;
    return this.refresh(userId);
  }

  async weeklyReview(userId: string) {
    const data = await this.sourceData(userId);
    const insights = this.generate(data).slice(0, 3);
    const priorities = data.goals.slice(0, 3).map(g => ({ id: g.id, title: g.title, lifeAreaId: g.lifeAreaId }));
    if (!priorities.length && data.assessments.length) {
      const latestByArea = new Map<string, (typeof data.assessments)[number]>();
      for (const assessment of data.assessments) {
        if (!latestByArea.has(assessment.areaId)) latestByArea.set(assessment.areaId, assessment);
      }
      const latest = [...latestByArea.values()].sort((a,b) => (b.importance - b.satisfaction) - (a.importance - a.satisfaction))[0];
      priorities.push({ id: latest.id, title: 'Escolher um pequeno passo nesta área', lifeAreaId: latest.areaId });
    }
    return {
      periodDays: 14,
      learningSampleSize: data.results.length,
      insights,
      priorities,
      questions: [
        'O que melhorou, mesmo que pouco?',
        'O que ficou mais difícil?',
        'O que aprendeste sobre o que funciona contigo?',
      ],
    };
  }
}
