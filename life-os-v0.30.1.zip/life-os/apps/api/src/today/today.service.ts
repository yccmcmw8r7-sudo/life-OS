import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service.js';
import { LifeAreaId, scoreAssessment } from '@life-os/scoring';
import { scoreAdaptiveAction } from '@life-os/scoring';
import { getLocalDayBounds, safeTimeZone } from '../common/local-day.js';

const AREA_NAMES: Record<string,string> = {
  RELATIONSHIPS:'Relacionamentos e Amor', FAMILY_FRIENDS:'Família e Amizades', EMOTIONAL_WELLBEING:'Bem-estar Emocional',
  HEALTH_ENERGY:'Saúde e Energia', FINANCES:'Finanças e Segurança', CAREER:'Carreira e Realização', AUTONOMY:'Autonomia e Liberdade',
  PURPOSE:'Propósito e Sentido', PLEASURE:'Prazer e Experiências', GROWTH:'Crescimento Pessoal'
};

@Injectable()
export class TodayService {
  constructor(private db: PrismaService) {}

  private template(goal: any, areaId?: string) {
    const area = AREA_NAMES[areaId ?? ''] ?? 'a tua vida';
    const title = goal?.title ? `Dar um passo pequeno em direção a “${goal.title}”` : `Fazer um pequeno passo em ${area}`;
    return { title, description: goal?.title ? `Dedica 10–20 minutos a uma ação concreta que aproxime este objetivo. Se parecer demasiado, reduz ainda mais o passo.` : `Escolhe uma ação de 10–20 minutos que possa melhorar ligeiramente esta área, sem tentar resolver tudo hoje.`, estimatedMinutes: 15, expectedImpact: 7, confidence: 7, effort: 3, complexity: 2 };
  }

  async build(userId: string) {
    const user = await this.db.user.findUnique({ where: { id: userId }, select: { timezone: true } });
    const { start, end, date } = getLocalDayBounds(new Date(), safeTimeZone(user?.timezone));
    const [pending, goals, assessments, recentResults, checkin] = await Promise.all([
      this.db.action.findMany({where:{userId,status:'PENDING',OR:[{scheduledDate:null},{scheduledDate:{gte:start,lt:end}}]},orderBy:{priorityScore:'desc'},take:10, include:{goal:true}}),
      this.db.goal.findMany({where:{userId,status:'ACTIVE'},orderBy:{updatedAt:'desc'},take:10}),
      this.db.lifeAreaAssessment.findMany({where:{userId},orderBy:{createdAt:'desc'},take:50}),
      this.db.actionResult.findMany({where:{userId},orderBy:{createdAt:'desc'},take:20,include:{action:true}}),
      this.db.checkin.findFirst({where:{userId,createdAt:{gte:start,lt:end}},orderBy:{createdAt:'desc'}})
    ]);

    const capacity = checkin?.energy != null ? Math.max(0, Math.min(10, checkin.energy)) : 6;
    const existingIds = new Set(pending.map(a => a.goalId).filter(Boolean));
    const generated: any[] = [];

    // One goal-linked action when the user has capacity and no current action for that goal.
    for (const goal of goals) {
      if (generated.length + pending.length >= 3) break;
      if (existingIds.has(goal.id)) continue;
      const t = this.template(goal, goal.lifeAreaId ?? undefined);
      const friction = Math.max(1, (t.effort + t.complexity) / 2);
      const score = (t.expectedImpact * t.confidence * Math.max(1, capacity)) / (friction * 100);
      generated.push(await this.db.action.create({data:{userId,goalId:goal.id,lifeAreaId:goal.lifeAreaId,title:t.title,description:t.description,estimatedMinutes:t.estimatedMinutes,expectedImpact:t.expectedImpact,confidence:t.confidence,effort:t.effort,complexity:t.complexity,priorityScore:score,scheduledDate:start}}));
    }

    // If there are no goals, use the latest life-map priority as a gentle starter action.
    if (generated.length + pending.length === 0 && assessments.length) {
      const scored = assessments.map(a => scoreAssessment({areaId:a.areaId as LifeAreaId,satisfaction:a.satisfaction,importance:a.importance,motivation:a.motivation,capacity:a.capacity})).sort((a,b)=>b.priority-a.priority)[0];
      if (scored) {
        const t = this.template(null, scored.areaId);
        generated.push(await this.db.action.create({data:{userId,lifeAreaId:scored.areaId,title:t.title,description:t.description,estimatedMinutes:t.estimatedMinutes,expectedImpact:t.expectedImpact,confidence:t.confidence,effort:t.effort,complexity:t.complexity,priorityScore:scored.priority,scheduledDate:start}}));
      }
    }

    // Keep only the latest assessment for each life area so old scores do not override newer ones.
    const latestAssessmentByArea = new Map<string, any>();
    for (const assessment of assessments) {
      if (!latestAssessmentByArea.has(assessment.areaId)) latestAssessmentByArea.set(assessment.areaId, assessment);
    }
    const all = [...pending, ...generated].map(action => {
      const history = recentResults.filter((r:any) => {
        if (action.goalId && r.action?.goalId === action.goalId) return true;
        return Boolean(action.lifeAreaId && r.action?.lifeAreaId === action.lifeAreaId);
      });
      const related = history.slice(0, 8);
      const average = (field:string) => {
        const values = related.map((r:any) => r[field]).filter((v:any) => typeof v === 'number');
        return values.length ? values.reduce((sum:number,v:number)=>sum+v,0)/values.length : undefined;
      };
      const latest = related[0];
      const areaAssessment = action.lifeAreaId ? latestAssessmentByArea.get(action.lifeAreaId) : undefined;
      const areaCapacity = areaAssessment?.capacity ?? capacity;
      const adaptive = scoreAdaptiveAction({
        priority: action.priorityScore ?? 0,
        expectedImpact: action.expectedImpact,
        confidence: action.confidence,
        effort: action.effort,
        complexity: action.complexity,
        estimatedMinutes: action.estimatedMinutes,
        areaCapacity,
        latestCompletion: latest?.completion,
        averageDifficulty: average('difficulty'),
        averageBenefit: average('benefit'),
        sampleSize: related.length,
      });
      return {...action, adaptiveScore:adaptive.score, adaptation: { explanation:adaptive.explanation, evidenceCount:related.length, capacityUsed:areaCapacity }};
    }).sort((a,b)=>b.adaptiveScore-a.adaptiveScore).slice(0, capacity <= 3 ? 1 : 3);
    return { date, capacity, actions:all, generatedCount:generated.length, learningSampleSize:recentResults.length, adaptationMode:recentResults.length >= 3 ? 'personalised' : 'starting-estimate' };
  }
}
