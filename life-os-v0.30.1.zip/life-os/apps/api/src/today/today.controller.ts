import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard.js';
import { TodayService } from './today.service.js';
@Controller('today') @UseGuards(AuthGuard)
export class TodayController { constructor(private service:TodayService){} @Get() get(@Req() r:any){return this.service.build(r.user.sub)} }
