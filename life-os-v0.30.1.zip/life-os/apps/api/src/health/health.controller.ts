import { Controller, Get, ServiceUnavailableException } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service.js';

/** Minimal probes for load balancers and deployment orchestration. Never expose secrets. */
@Controller('health')
export class HealthController {
  constructor(private readonly db: PrismaService) {}

  /** Process liveness only: intentionally does not depend on external services. */
  @Get('live')
  live() {
    return { status: 'ok' as const };
  }

  /** Readiness confirms the database can answer a trivial query. */
  @Get('ready')
  async ready() {
    try {
      await this.db.$queryRaw`SELECT 1`;
      return { status: 'ok' as const, checks: { database: 'ok' as const } };
    } catch {
      // Do not leak connection strings, database errors, or infrastructure details.
      throw new ServiceUnavailableException({
        status: 'error',
        checks: { database: 'unavailable' },
      });
    }
  }
}
