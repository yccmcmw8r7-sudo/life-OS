import { Body, Controller, Post, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard.js';
import { AIGateway } from './ai.gateway.js';
@Controller('ai')
@UseGuards(AuthGuard)
export class AIController {
  constructor(private readonly ai: AIGateway) {}
  @Post('chat') chat(@Body() body: any) { return this.ai.respond(body); }
}
