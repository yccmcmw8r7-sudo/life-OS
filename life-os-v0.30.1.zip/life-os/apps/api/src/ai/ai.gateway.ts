import { Injectable } from '@nestjs/common';
import { SafetyService } from '../safety/safety.service.js';

export type AIRequest = {
  userMessage: string;
  relevantMemory?: Array<{ category: string; content: string; userConfirmed: boolean }>;
  lifeState?: unknown;
  goals?: unknown[];
  currentPriority?: unknown;
};
export type AIResponse = {
  message: string;
  insight?: string;
  questions: string[];
  suggested_actions: string[];
  needs_confirmation: boolean;
  safety: 'SAFE' | 'CAUTION' | 'HIGH_RISK';
  provider: 'configured-model' | 'safe-fallback';
};

@Injectable()
export class AIGateway {
  constructor(private readonly safety: SafetyService) {}

  async respond(input: AIRequest): Promise<AIResponse> {
    const message = typeof input.userMessage === 'string' ? input.userMessage.trim() : '';
    if (!message || message.length > 4000) {
      return { message: 'Escreve uma mensagem com até 4000 caracteres para podermos começar.', questions: [], suggested_actions: [], needs_confirmation: false, safety: 'SAFE', provider: 'safe-fallback' };
    }
    const safety = this.safety.classify(message);
    if (safety.level === 'HIGH_RISK') {
      return { message: 'Lamento que estejas a passar por algo tão difícil. Não quero tratar uma situação potencialmente urgente como uma conversa de produtividade. Se estiveres em perigo imediato, liga 112. Em Portugal, podes também procurar apoio de saúde através do SNS 24 (808 24 24 24) ou falar agora com alguém de confiança. Não precisas de lidar com isto sem apoio humano.', questions: [], suggested_actions: [], needs_confirmation: false, safety: 'HIGH_RISK', provider: 'safe-fallback' };
    }

    const apiKey = process.env.AI_API_KEY;
    const endpoint = process.env.AI_API_URL ?? 'https://api.openai.com/v1/chat/completions';
    const model = process.env.AI_MODEL ?? 'gpt-4o-mini';
    if (apiKey) {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 15000);
        try {
          const response = await fetch(endpoint, {
            method: 'POST', signal: controller.signal,
            headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ model, temperature: 0.4, max_tokens: 700, response_format: { type: 'json_object' }, messages: [
              { role: 'system', content: `És o LIFE OS, um companheiro de reflexão em português europeu. Ajuda a pessoa a pensar, não decidas por ela. Não diagnostiques nem substituas profissionais. Usa linguagem probabilística, não inventes factos nem padrões. Memórias são pistas, não verdades; pede confirmação. Sugere no máximo 3 micro-ações concretas, leves e opcionais. Não incentiva dependência da app. Devolve APENAS JSON com: message (string), insight (string opcional), questions (array de strings), suggested_actions (array de strings), needs_confirmation (boolean).` },
              { role: 'user', content: JSON.stringify({ userMessage: message, relevantMemory: (input.relevantMemory ?? []).slice(0, 8), lifeState: input.lifeState, goals: input.goals, currentPriority: input.currentPriority, safetyLevel: safety.level }) }
            ] })
          });
          if (!response.ok) throw new Error(`AI provider returned ${response.status}`);
          const payload: any = await response.json();
          const raw = payload?.choices?.[0]?.message?.content;
          const parsed = typeof raw === 'string' ? JSON.parse(raw) : null;
          if (typeof parsed?.message !== 'string' || !Array.isArray(parsed.questions) || !Array.isArray(parsed.suggested_actions)) throw new Error('Invalid AI response schema');
          return { message: parsed.message.slice(0, 5000), insight: typeof parsed.insight === 'string' ? parsed.insight.slice(0, 1500) : undefined, questions: parsed.questions.filter((x: unknown) => typeof x === 'string').slice(0, 3), suggested_actions: parsed.suggested_actions.filter((x: unknown) => typeof x === 'string').slice(0, 3), needs_confirmation: parsed.needs_confirmation !== false, safety: safety.level, provider: 'configured-model' };
        } finally { clearTimeout(timeout); }
      } catch {
        // Never expose provider errors, keys, or user context to the client. Fall back safely.
      }
    }
    return { message: safety.level === 'CAUTION' ? 'Podemos explorar isto com cuidado, sem tirar conclusões precipitadas. Não tens de resolver tudo agora.' : 'Estou aqui para te ajudar a pensar sobre isto, sem decidir por ti. Ainda não tenho um modelo de IA configurado, por isso esta é uma resposta inicial e não uma análise personalizada.', questions: ['O que é mais importante para ti neste momento?'], suggested_actions: [], needs_confirmation: true, safety: safety.level, provider: 'safe-fallback' };
  }
}
