import type {DominoMatrix, LifeAreaId} from '@life-os/scoring';

export const AREA_IDS: readonly LifeAreaId[] = [
  'RELATIONSHIPS', 'FAMILY_FRIENDS', 'EMOTIONAL_WELLBEING', 'HEALTH_ENERGY',
  'FINANCES', 'CAREER', 'AUTONOMY', 'PURPOSE', 'PLEASURE', 'GROWTH',
];

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

export function validateAssessments(input: unknown) {
  if (!Array.isArray(input) || input.length !== AREA_IDS.length) {
    throw new Error('São necessárias 10 avaliações.');
  }
  const seen = new Set<string>();
  for (const assessment of input as unknown[]) {
    if (!isRecord(assessment) || typeof assessment.areaId !== 'string' ||
        !AREA_IDS.includes(assessment.areaId as LifeAreaId) || seen.has(assessment.areaId)) {
      throw new Error('Área inválida ou repetida.');
    }
    seen.add(assessment.areaId);
    for (const key of ['satisfaction', 'importance', 'motivation', 'capacity'] as const) {
      const value = assessment[key];
      if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 10) {
        throw new Error(`Valor inválido: ${key}.`);
      }
    }
  }
  return input as {areaId: LifeAreaId; satisfaction: number; importance: number; motivation: number; capacity: number}[];
}

/** Validates the optional influence matrix before any assessment is persisted. */
export function validateDominoMatrix(input: unknown): DominoMatrix {
  if (input === undefined || input === null) return {};
  if (!isRecord(input)) throw new Error('A matriz de influência tem de ser um objeto.');

  const matrix: DominoMatrix = {};
  for (const [source, rawTargets] of Object.entries(input)) {
    if (!AREA_IDS.includes(source as LifeAreaId) || !isRecord(rawTargets)) {
      throw new Error('Área inválida na matriz de influência.');
    }
    const targets: Partial<Record<LifeAreaId, number>> = {};
    for (const [target, weight] of Object.entries(rawTargets)) {
      if (!AREA_IDS.includes(target as LifeAreaId)) {
        throw new Error('Área de destino inválida na matriz de influência.');
      }
      if (source === target) throw new Error('A matriz não pode conter influência sobre a própria área.');
      if (typeof weight !== 'number' || !Number.isFinite(weight) || weight < 0 || weight > 5) {
        throw new Error('Os pesos da matriz devem ser números entre 0 e 5.');
      }
      targets[target as LifeAreaId] = weight;
    }
    matrix[source as LifeAreaId] = targets;
  }
  return matrix;
}
