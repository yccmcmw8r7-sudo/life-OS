/** CORS is a browser policy, not authentication. Non-browser/native clients often omit Origin. */
export function isAllowedBrowserOrigin(origin: string | undefined, allowedOrigins: ReadonlySet<string>): boolean {
  return !origin || allowedOrigins.has(origin);
}
