/** Calendar-day boundaries for a user's IANA time zone, including DST transitions. */
export const DEFAULT_TIME_ZONE = 'Europe/Lisbon';

/** Return a valid IANA zone; bad/stale profile values must not break core requests. */
export function safeTimeZone(value: unknown, fallback = DEFAULT_TIME_ZONE): string {
  if (typeof value !== 'string' || !value.trim()) return fallback;
  try { new Intl.DateTimeFormat('en-US', { timeZone: value }).format(); return value; }
  catch { return fallback; }
}

export interface LocalDayBounds {
  start: Date;
  end: Date;
  date: string;
}

function localParts(date: Date, timeZone: string) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date);
  const values = Object.fromEntries(parts.map(p => [p.type, p.value]));
  return {
    year: Number(values.year), month: Number(values.month), day: Number(values.day),
    hour: Number(values.hour), minute: Number(values.minute), second: Number(values.second),
  };
}

function zonedMidnightUtc(year: number, month: number, day: number, timeZone: string): Date {
  const targetWallClock = Date.UTC(year, month - 1, day, 0, 0, 0);
  let candidate = targetWallClock;
  // Reconcile the UTC candidate with how that instant renders in the target zone.
  // Iteration also handles 23/25-hour days around daylight-saving transitions.
  for (let i = 0; i < 4; i++) {
    const p = localParts(new Date(candidate), timeZone);
    const renderedWallClock = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
    const correction = targetWallClock - renderedWallClock;
    candidate += correction;
    if (correction === 0) break;
  }
  return new Date(candidate);
}

export function getLocalDayBounds(now: Date, timeZone = 'Europe/Lisbon'): LocalDayBounds {
  if (!Number.isFinite(now.getTime())) throw new RangeError('Data inválida.');
  // Intl validates IANA zone names and throws RangeError for an unknown zone.
  const p = localParts(now, timeZone);
  const next = new Date(Date.UTC(p.year, p.month - 1, p.day + 1));
  const start = zonedMidnightUtc(p.year, p.month, p.day, timeZone);
  const end = zonedMidnightUtc(next.getUTCFullYear(), next.getUTCMonth() + 1, next.getUTCDate(), timeZone);
  return { start, end, date: `${p.year}-${String(p.month).padStart(2, '0')}-${String(p.day).padStart(2, '0')}` };
}
