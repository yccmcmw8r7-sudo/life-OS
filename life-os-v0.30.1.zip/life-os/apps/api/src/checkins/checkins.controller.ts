import { Body, Controller, Get, Post, Req, UseGuards, BadRequestException } from '@nestjs/common';
import { IsInt, IsOptional, IsString, Max, Min, MaxLength } from 'class-validator';
import { PrismaService } from '../common/prisma.service.js';
import { AuthGuard } from '../auth/auth.guard.js';
import { getLocalDayBounds, safeTimeZone } from '../common/local-day.js';

class CheckinDto {
  @IsOptional() @IsInt() @Min(0) @Max(10) mood?: number;
  @IsOptional() @IsInt() @Min(0) @Max(10) energy?: number;
  @IsOptional() @IsInt() @Min(0) @Max(10) stress?: number;
  @IsOptional() @IsString() @MaxLength(300) importantEvent?: string;
  @IsOptional() @IsString() @MaxLength(2000) notes?: string;
}

@Controller('checkins')
@UseGuards(AuthGuard)
export class CheckinsController {
  constructor(private db: PrismaService) {}

  @Get('latest')
  async latest(@Req() req: any) {
    const user = await this.db.user.findUnique({ where: { id: req.user.sub }, select: { timezone: true } });
    const { start, end } = getLocalDayBounds(new Date(), safeTimeZone(user?.timezone));
    return this.db.checkin.findFirst({ where: { userId: req.user.sub, createdAt: { gte: start, lt: end } }, orderBy: { createdAt: 'desc' } });
  }

  @Post()
  async createOrUpdateToday(@Req() req: any, @Body() data: CheckinDto) {
    if (data.mood === undefined && data.energy === undefined && data.stress === undefined && !data.importantEvent?.trim() && !data.notes?.trim()) {
      throw new BadRequestException('Escolhe pelo menos um valor ou acrescenta uma nota.');
    }
    const user = await this.db.user.findUnique({ where: { id: req.user.sub }, select: { timezone: true } });
    const { start, end } = getLocalDayBounds(new Date(), safeTimeZone(user?.timezone));
    const existing = await this.db.checkin.findFirst({
      where: { userId: req.user.sub, createdAt: { gte: start, lt: end } },
      orderBy: { createdAt: 'desc' },
    });
    if (existing) {
      return this.db.checkin.update({ where: { id: existing.id }, data });
    }
    return this.db.checkin.create({ data: { userId: req.user.sub, ...data } });
  }
}
