# LIFE OS v0.28 — CI e preparação de lançamento

## O que mudou
- Declarada explicitamente a dependência de runtime `@prisma/client` na API, alinhada com o Prisma CLI (`6.17.1`). O serviço Prisma importa esse pacote; sem a dependência explícita, instalações limpas podem falhar.
- Adicionado workflow GitHub Actions para instalar dependências, gerar o Prisma Client, executar contratos de segurança/base de dados, testes do scoring e API, teste de idioma móvel e typechecks da API e aplicação móvel.
- Adicionados testes de release readiness para detetar divergências entre versões do Prisma, versões móveis/Expo e etapas essenciais do workflow CI.
- Criado um comando consolidado `npm run verify:release-readiness` e integrado no `npm run test:contracts`.
- Versão móvel e Expo atualizadas para `0.28.0`.

## Validação local desta entrega
Os testes independentes de dependências e verificadores estáticos podem ser executados com Node.js. O workflow GitHub Actions é definido, mas só poderá ser considerado aprovado depois de correr num runner com acesso ao npm. Não foi executada uma instalação npm completa nesta entrega.

## Antes de produção
- Executar CI num runner real e resolver todos os erros.
- Validar migrações numa base PostgreSQL descartável e testar exportação/eliminação de conta com dados reais de teste.
- Confirmar backups, recuperação, monitorização, gestão de segredos e política de retenção.
- Rever privacidade/GDPR, segurança e builds iOS/Android antes de qualquer lançamento público.
