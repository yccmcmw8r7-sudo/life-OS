# LIFE OS v0.30.1 — correção do arranque de CI

## Problema resolvido no projeto

- Removida a configuração `cache: npm` do `setup-node`, que pressupõe a existência de um lockfile e pode falhar antes da instalação quando `package-lock.json` não está no repositório.
- A instalação do CI passa a usar retries explícitos para falhas transitórias do registo npm.
- O CI preserva o `package-lock.json` gerado durante uma instalação bem-sucedida como artefacto por 7 dias, para permitir a sua revisão e inclusão no repositório.
- Node.js do CI atualizado para a versão 22, alinhada com o ambiente de desenvolvimento utilizado nesta correção.
- Acrescentado teste de contrato para impedir regressões na configuração de bootstrap do CI.
- Versões da aplicação móvel e do Expo atualizadas para `0.30.1`.

## Limitação conhecida

Este patch remove um bloqueio de configuração do GitHub Actions e melhora a recuperação do lockfile. Não corrige a falha DNS `EAI_AGAIN` observada no ambiente de execução local; essa falha de conectividade exige um registo npm acessível. O CI remoto ainda tem de ser executado para confirmar a instalação e os testes completos.
