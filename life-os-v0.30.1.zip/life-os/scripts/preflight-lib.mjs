/** Small, dependency-free deployment checks. These checks do not replace a security review. */
export function validateProductionEnvironment(env = {}) {
  const errors = [];
  const databaseUrl = String(env.DATABASE_URL ?? '').trim();
  if (!databaseUrl) errors.push('DATABASE_URL is required.');
  else {
    try {
      const parsed = new URL(databaseUrl);
      if (!['postgres:', 'postgresql:'].includes(parsed.protocol)) errors.push('DATABASE_URL must use PostgreSQL.');
      if (['localhost', '127.0.0.1', '::1'].includes(parsed.hostname)) errors.push('DATABASE_URL points to localhost; use the intended production/staging database.');
      if (/(^|[?&])sslmode=(disable|allow)(?:&|$)/i.test(parsed.search)) errors.push('DATABASE_URL must not explicitly disable or weaken TLS with sslmode=disable/allow.');
    } catch { errors.push('DATABASE_URL is not a valid URL.'); }
  }

  const jwt = String(env.JWT_SECRET ?? '');
  if (jwt.length < 32) errors.push('JWT_SECRET must contain at least 32 characters.');
  if (/replace-with|change-me|secret123|example/i.test(jwt)) errors.push('JWT_SECRET appears to be a placeholder.');

  const origins = String(env.CORS_ORIGINS ?? '').split(',').map((x) => x.trim()).filter(Boolean);
  if (origins.includes('*')) errors.push('CORS_ORIGINS must not contain a wildcard.');
  for (const origin of origins) {
    try {
      const url = new URL(origin);
      if (!['https:', 'http:'].includes(url.protocol) || url.pathname !== '/' || url.search || url.hash) errors.push(`CORS origin is not a bare origin: ${origin}`);
      else if (url.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(url.hostname)) errors.push(`CORS origin must use HTTPS outside localhost: ${origin}`);
    } catch { errors.push(`CORS origin is invalid: ${origin}`); }
  }

  const aiKey = String(env.AI_API_KEY ?? '').trim();
  const aiUrl = String(env.AI_API_URL ?? '').trim();
  if (aiKey && !aiUrl) errors.push('AI_API_URL is required when AI_API_KEY is configured.');
  if (aiKey && aiUrl) {
    try {
      const url = new URL(aiUrl);
      if (url.protocol !== 'https:') errors.push('AI_API_URL must use HTTPS when an AI key is configured.');
    } catch { errors.push('AI_API_URL is not a valid URL.'); }
  }

  const port = String(env.PORT ?? '3000');
  if (!/^\d+$/.test(port) || Number(port) < 1 || Number(port) > 65535) errors.push('PORT must be an integer between 1 and 65535.');
  return errors;
}

export function validateStaticSecurityContracts({ mainSource, corsSource }) {
  const errors = [];
  if (!/ValidationPipe\s*\(\s*\{[^}]*whitelist:\s*true/s.test(mainSource)) errors.push('Global ValidationPipe whitelist is missing.');
  if (!/forbidNonWhitelisted:\s*true/.test(mainSource)) errors.push('Global ValidationPipe must reject unknown request properties.');
  if (!/isAllowedBrowserOrigin\s*\(origin,\s*allowedOrigins\)/.test(mainSource)) errors.push('CORS must delegate browser origins to the allow-list policy.');
  if (!/origin\s*===\s*undefined/.test(corsSource) && !/!origin/.test(corsSource)) errors.push('CORS policy should explicitly handle native clients without an Origin header.');
  if (/origin\s*:\s*['"]\*['"]/.test(mainSource)) errors.push('Wildcard CORS configuration detected.');
  return errors;
}
