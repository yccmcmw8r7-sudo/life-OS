/** Dependency-free static regression checks for account export/deletion security boundaries. */
export function validateAccountController(source) {
  const errors = [];
  const requirePattern = (pattern, message) => {
    if (!pattern.test(source)) errors.push(message);
  };

  requirePattern(/@Controller\(['"]account['"]\)[\s\S]*?@UseGuards\(AuthGuard\)/,
    'Account controller must be protected by AuthGuard.');
  requirePattern(/@Get\(['"]export['"]\)[\s\S]*?@Header\(['"]Cache-Control['"],\s*['"]no-store, private['"]\)/,
    'Account export must disable shared/private caching.');
  requirePattern(/select:\s*\{[^}]*\bid:\s*true[^}]*\bemail:\s*true[^}]*\bname:\s*true[^}]*\}/s,
    'Account export must explicitly select an allow-list of profile fields.');

  const exportMethod = source.match(/async\s+exportData\([\s\S]*?(?=\n\s*\/\*\*|\n\s*@Delete\()/)?.[0] ?? '';
  if (!exportMethod) errors.push('Account export method could not be isolated for validation.');
  if (/passwordHash|password\s*:\s*true/i.test(exportMethod)) {
    errors.push('Account export must never include password credentials.');
  }
  const scopedQueries = (exportMethod.match(/where:\s*\{\s*userId\s*\}/g) ?? []).length;
  if (scopedQueries < 7) errors.push('All seven user-owned export collections must be scoped to the authenticated user.');

  requirePattern(/body\.confirmation\s*!==\s*['"]DELETE MY ACCOUNT['"]/, 
    'Account deletion must require the exact destructive confirmation phrase.');
  requirePattern(/user\.email\.toLowerCase\(\)\s*!==\s*body\.email\.trim\(\)\.toLowerCase\(\)/,
    'Account deletion must verify the submitted email against the authenticated account.');
  requirePattern(/bcrypt\.compare\(body\.password,\s*user\.passwordHash\)/,
    'Account deletion must verify the current password.');
  requirePattern(/this\.db\.user\.delete\(\{\s*where:\s*\{\s*id:\s*userId\s*\}\s*\}\)/,
    'Account deletion must delete only the authenticated user ID.');

  return errors;
}
