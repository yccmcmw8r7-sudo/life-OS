import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const readJson = (path) => JSON.parse(readFileSync(new URL(`../../${path}`, import.meta.url), 'utf8'));

test('Prisma runtime client is an explicit API dependency and matches Prisma major/minor', () => {
  const api = readJson('apps/api/package.json');
  const client = api.dependencies['@prisma/client'];
  const cli = api.dependencies.prisma;
  assert.ok(client, '@prisma/client must be installed in API runtime');
  assert.ok(cli, 'Prisma CLI dependency must be declared');
  assert.equal(client.replace(/^\^/, ''), cli.replace(/^\^/, ''), 'Prisma CLI and generated client versions must match');
});

test('mobile app and Expo release versions are aligned', () => {
  const mobile = readJson('apps/mobile/package.json');
  const expo = readJson('apps/mobile/app.json');
  assert.equal(mobile.version, expo.expo.version);
  assert.equal(mobile.version, '0.30.1');
});

test('CI includes PostgreSQL-backed persistence and account-deletion integration tests', () => {
  const workflow = readFileSync(new URL('../../.github/workflows/ci.yml', import.meta.url), 'utf8');
  assert.ok(workflow.includes('services:'), 'CI must define a PostgreSQL service');
  assert.ok(workflow.includes('npm run test:postgres'), 'CI must run PostgreSQL integration tests');
  assert.ok(workflow.includes('prisma db push'), 'CI must prepare a disposable schema');
});

test('CI includes generation and both mobile/API typechecks', () => {
  const workflow = readFileSync(new URL('../../.github/workflows/ci.yml', import.meta.url), 'utf8');
  for (const required of [
    'npx prisma generate --schema apps/api/prisma/schema.prisma',
    'npm run test:contracts',
    'npm run verify:scoring',
    'npm run typecheck -w @life-os/api',
    'npm run typecheck -w @life-os/mobile',
  ]) assert.ok(workflow.includes(required), `CI missing step: ${required}`);
});


test('API unit suite includes executable authentication and token-validation regressions', () => {
  const guardTests = readFileSync(new URL('../../apps/api/test/auth-guard.test.ts', import.meta.url), 'utf8');
  const serviceTests = readFileSync(new URL('../../apps/api/test/auth-service.test.ts', import.meta.url), 'utf8');
  for (const required of ['missing and non-Bearer', 'expired and incorrectly signed', 'attaches verified claims', 'JWT_SECRET is absent']) {
    assert.ok(guardTests.includes(required), `AuthGuard test coverage missing: ${required}`);
  }
  for (const required of ['normalizes email', 'existing email', 'incorrect passwords', 'valid password']) {
    assert.ok(serviceTests.includes(required), `AuthService test coverage missing: ${required}`);
  }
  const authService = readFileSync(new URL('../../apps/api/src/auth/auth.service.ts', import.meta.url), 'utf8');
  assert.ok((authService.match(/email:email\.trim\(\)\.toLowerCase\(\)/g) ?? []).length >= 3, 'register and login must trim and normalize email');
});


test('root workspace declares Node.js types required by source and tests', () => {
  const root = readJson('package.json');
  assert.ok(root.devDependencies['@types/node'], 'declare @types/node instead of relying on transitive packages');
});

test('CI bootstrap does not require a missing lockfile and preserves the generated lockfile', () => {
  const workflow = readFileSync(new URL('../../.github/workflows/ci.yml', import.meta.url), 'utf8');
  assert.ok(!workflow.includes('cache: npm'), 'npm cache setup must not fail when package-lock.json is absent');
  assert.ok(workflow.includes('npm install --no-audit --no-fund'), 'CI must install dependencies without audit/network overhead');
  assert.ok(workflow.includes('--fetch-retries=3'), 'CI install must retry transient registry failures');
  assert.ok(workflow.includes('actions/upload-artifact@v4'), 'CI must preserve generated package-lock.json as an artifact');
  assert.ok(workflow.includes('path: package-lock.json'), 'CI lockfile artifact must contain package-lock.json');
});
