import test from 'node:test';
import assert from 'node:assert/strict';
import { validateProductionEnvironment, validateStaticSecurityContracts } from '../preflight-lib.mjs';

const valid = {
  DATABASE_URL: 'postgresql://app:pass@db.example.net:5432/lifeos?sslmode=require',
  JWT_SECRET: 'a-long-random-secret-value-with-more-than-32-chars',
  CORS_ORIGINS: 'https://app.example.com',
  AI_API_KEY: '',
  PORT: '3000',
};

test('accepts a production-shaped environment', () => {
  assert.deepEqual(validateProductionEnvironment(valid), []);
});

test('rejects missing database and short JWT secret', () => {
  const errors = validateProductionEnvironment({ ...valid, DATABASE_URL: '', JWT_SECRET: 'short' });
  assert.ok(errors.some((x) => x.includes('DATABASE_URL is required')));
  assert.ok(errors.some((x) => x.includes('at least 32 characters')));
});

test('rejects localhost database, wildcard CORS and non-HTTPS external origin', () => {
  const errors = validateProductionEnvironment({ ...valid, DATABASE_URL: 'postgresql://localhost/lifeos', CORS_ORIGINS: '*,http://app.example.com' });
  assert.ok(errors.some((x) => x.includes('localhost')));
  assert.ok(errors.some((x) => x.includes('wildcard')));
  assert.ok(errors.some((x) => x.includes('must use HTTPS')));
});

test('requires HTTPS for configured AI provider and valid port', () => {
  const errors = validateProductionEnvironment({ ...valid, AI_API_KEY: 'configured', AI_API_URL: 'http://ai.example.com', PORT: '70000' });
  assert.ok(errors.some((x) => x.includes('AI_API_URL must use HTTPS')));
  assert.ok(errors.some((x) => x.includes('PORT must be an integer')));
});

test('static API security contracts detect expected guards', () => {
  const errors = validateStaticSecurityContracts({
    mainSource: "new ValidationPipe({ whitelist: true, transform: true, forbidNonWhitelisted: true }); isAllowedBrowserOrigin(origin, allowedOrigins)",
    corsSource: 'if (origin === undefined) return true;',
  });
  assert.deepEqual(errors, []);
});
