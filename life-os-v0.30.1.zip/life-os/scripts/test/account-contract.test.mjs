import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { validateAccountController } from '../account-contract-lib.mjs';

const source = readFileSync(resolve(process.cwd(), 'apps/api/src/account/account.controller.ts'), 'utf8');

test('accepts the current account security contract', () => {
  assert.deepEqual(validateAccountController(source), []);
});

test('detects removal of authentication guard', () => {
  assert.ok(validateAccountController(source.replace('@UseGuards(AuthGuard)', '@UseGuards(OtherGuard)'))
    .some((error) => error.includes('AuthGuard')));
});

test('detects credential leakage in export', () => {
  const changed = source.replace('async exportData(', 'async exportData(').replace('select: { id: true, email: true, name: true, timezone: true, language: true, createdAt: true, updatedAt: true }', 'select: { id: true, email: true, passwordHash: true }');
  assert.ok(validateAccountController(changed).some((error) => error.includes('password credentials')));
});

test('detects unscoped export collection queries', () => {
  const changed = source.replace('this.db.goal.findMany({ where: { userId },', 'this.db.goal.findMany({ where: {},');
  assert.ok(validateAccountController(changed).some((error) => error.includes('scoped to the authenticated user')));
});

test('detects missing destructive confirmation', () => {
  const changed = source.replace("body.confirmation !== 'DELETE MY ACCOUNT'", "body.confirmation !== 'DELETE'");
  assert.ok(validateAccountController(changed).some((error) => error.includes('confirmation phrase')));
});

test('detects deletion without current password verification', () => {
  const changed = source.replace('!(await bcrypt.compare(body.password, user.passwordHash))', 'false');
  assert.ok(validateAccountController(changed).some((error) => error.includes('current password')));
});

test('detects deletion not scoped to authenticated user ID', () => {
  const changed = source.replace('this.db.user.delete({ where: { id: userId } })', 'this.db.user.delete({ where: { email: body.email } })');
  assert.ok(validateAccountController(changed).some((error) => error.includes('authenticated user ID')));
});
