#!/usr/bin/env node
/** Dependency-free guard for the LIFE OS account-deletion FK contract. */
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const root = process.cwd();
const read = (path) => readFileSync(resolve(root, path), 'utf8');
const bootstrap = read('db/schema.sql');
const migration = read('db/migrations/20261009_account_deletion_cascade.sql');
const prisma = read('apps/api/prisma/schema.prisma');
const errors = [];

const expected = [
  { table: 'life_area_assessments', column: 'user_id', target: 'users(id)', action: 'CASCADE' },
  { table: 'goals', column: 'user_id', target: 'users(id)', action: 'CASCADE' },
  { table: 'actions', column: 'user_id', target: 'users(id)', action: 'CASCADE' },
  { table: 'actions', column: 'goal_id', target: 'goals(id)', action: 'SET NULL' },
  { table: 'checkins', column: 'user_id', target: 'users(id)', action: 'CASCADE' },
  { table: 'ai_memories', column: 'user_id', target: 'users(id)', action: 'CASCADE' },
  { table: 'insights', column: 'user_id', target: 'users(id)', action: 'CASCADE' },
  { table: 'action_results', column: 'action_id', target: 'actions(id)', action: 'CASCADE' },
  { table: 'action_results', column: 'user_id', target: 'users(id)', action: 'CASCADE' },
];

for (const fk of expected) {
  const label = `${fk.table}.${fk.column} -> ${fk.target} ON DELETE ${fk.action}`;
  const sqlPattern = new RegExp(
    `\\b${fk.column}\\s+[^,\\n]*?references\\s+${fk.target.replace(/[()]/g, '\\$&')}\\s+on\\s+delete\\s+${fk.action.replace(' ', '\\s+')}`,
    'i',
  );
  // Inspect only the CREATE TABLE block for this table, so unrelated constraints cannot satisfy it.
  const createMatch = bootstrap.match(new RegExp(`create\\s+table\\s+if\\s+not\\s+exists\\s+${fk.table}\\s*\\(([\\s\\S]*?)\\n\\);`, 'i'));
  if (!createMatch || !sqlPattern.test(createMatch[1])) errors.push(`Fresh schema missing: ${label}`);

  const migrationPattern = new RegExp(
    `alter\\s+table\\s+${fk.table}\\s+add\\s+constraint\\s+\\w+\\s+foreign\\s+key\\s*\\(\\s*${fk.column}\\s*\\)\\s+references\\s+${fk.target.replace(/[()]/g, '\\$&')}\\s+on\\s+delete\\s+${fk.action.replace(' ', '\\s+')}`,
    'i',
  );
  if (!migrationPattern.test(migration)) errors.push(`Upgrade migration missing: ${label}`);
}

const models = [
  ['LifeAreaAssessment', /user\s+User\s+@relation\(fields:\s*\[userId\],\s*references:\s*\[id\],\s*onDelete:\s*Cascade\)/],
  ['Goal', /user\s+User\s+@relation\(fields:\s*\[userId\],\s*references:\s*\[id\],\s*onDelete:\s*Cascade\)/],
  ['Action', /user\s+User\s+@relation\(fields:\s*\[userId\],\s*references:\s*\[id\],\s*onDelete:\s*Cascade\)/],
  ['Action', /goal\s+Goal\?\s+@relation\(fields:\s*\[goalId\],\s*references:\s*\[id\],\s*onDelete:\s*SetNull\)/],
  ['Checkin', /user\s+User\s+@relation\(fields:\s*\[userId\],\s*references:\s*\[id\],\s*onDelete:\s*Cascade\)/],
  ['AiMemory', /user\s+User\s+@relation\(fields:\s*\[userId\],\s*references:\s*\[id\],\s*onDelete:\s*Cascade\)/],
  ['Insight', /user\s+User\s+@relation\(fields:\s*\[userId\],\s*references:\s*\[id\],\s*onDelete:\s*Cascade\)/],
  ['ActionResult', /action\s+Action\s+@relation\(fields:\s*\[actionId\],\s*references:\s*\[id\],\s*onDelete:\s*Cascade\)/],
  ['ActionResult', /user\s+User\s+@relation\(fields:\s*\[userId\],\s*references:\s*\[id\],\s*onDelete:\s*Cascade\)/],
];
for (const [modelName, relationPattern] of models) {
  const block = prisma.match(new RegExp(`model\\s+${modelName}\\s*\\{([\\s\\S]*?)\\n\\}`, 'i'))?.[1];
  if (!block || !relationPattern.test(block)) errors.push(`Prisma relation missing in ${modelName}: ${relationPattern}`);
}

if (!/\bbegin\s*;/i.test(migration) || !/commit\s*;\s*$/i.test(migration)) {
  errors.push('Upgrade migration must be wrapped in BEGIN/COMMIT.');
}

if (errors.length) {
  console.error('Database contract verification FAILED:');
  for (const error of errors) console.error(` - ${error}`);
  process.exitCode = 1;
} else {
  console.log(`Database contract verification passed (${expected.length} SQL foreign-key rules checked across bootstrap SQL, upgrade migration and Prisma).`);
}
