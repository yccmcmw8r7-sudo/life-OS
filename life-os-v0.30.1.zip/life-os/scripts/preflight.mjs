#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { validateProductionEnvironment, validateStaticSecurityContracts } from './preflight-lib.mjs';

const root = process.cwd();
const read = (p) => readFileSync(resolve(root, p), 'utf8');
const errors = [
  ...validateStaticSecurityContracts({
    mainSource: read('apps/api/src/main.ts'),
    corsSource: read('apps/api/src/common/cors-policy.ts'),
  }),
];
if (process.argv.includes('--production')) errors.push(...validateProductionEnvironment(process.env));
if (errors.length) {
  console.error('LIFE OS preflight FAILED:');
  for (const error of errors) console.error(` - ${error}`);
  process.exitCode = 1;
} else {
  console.log(process.argv.includes('--production')
    ? 'LIFE OS preflight passed (static contracts and production environment shape). This is not a full security audit.'
    : 'LIFE OS static preflight passed. Run with --production to validate deployment environment variables.');
}
