#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { validateAccountController } from './account-contract-lib.mjs';

const source = readFileSync(resolve(process.cwd(), 'apps/api/src/account/account.controller.ts'), 'utf8');
const errors = validateAccountController(source);
if (errors.length) {
  console.error('Account security contract verification FAILED:');
  for (const error of errors) console.error(` - ${error}`);
  process.exitCode = 1;
} else {
  console.log('Account security contract passed (auth guard, private export, user scoping, confirmation, email/password verification, authenticated deletion target).');
}
