# LIFE OS v0.25 — database contract preflight

## O que mudou
- Adicionado `npm run verify:db-contract`, um verificador Node.js sem dependências externas.
- O verificador compara nove regras de chaves estrangeiras entre o SQL de instalação nova, a migração de atualização e as relações Prisma.
- A migração de eliminação de conta passa a executar dentro de `BEGIN`/`COMMIT`, para que uma falha reverta o conjunto de alterações em vez de deixar uma atualização parcial.
- Versão da aplicação móvel e versão Expo alinhadas em `0.25.0`.

## Verificação
Na raiz do repositório, executar:

```bash
npm run verify:db-contract
```

O comando valida consistência estática dos ficheiros; **não** liga a PostgreSQL nem prova o comportamento real de cascata. Antes de produção, fazer backup, executar a migração numa base de staging descartável com `psql -v ON_ERROR_STOP=1 -f db/migrations/20261009_account_deletion_cascade.sql` e verificar a eliminação com dados de teste. A migração deve ser aplicada apenas depois de confirmar que o esquema da base de dados corresponde às tabelas/nomes de constraints esperados.

## Ainda pendente
- Execução da migração numa instância PostgreSQL real e teste de eliminação de conta com registos relacionados.
- Instalação das dependências do workspace e execução dos testes completos, typecheck e builds Expo.
- Testes iOS/Android em dispositivos reais.
