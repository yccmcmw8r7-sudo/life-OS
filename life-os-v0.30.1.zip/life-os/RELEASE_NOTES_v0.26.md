# LIFE OS v0.26 — deployment preflight

## O que mudou
- Adicionado `npm run preflight` para verificar contratos estáticos da API: validação global de pedidos, rejeição de propriedades inesperadas e política CORS por lista permitida.
- Adicionado `npm run preflight:production` para verificar variáveis de ambiente antes de uma implementação: URL PostgreSQL, segredo JWT, origens CORS, configuração opcional do fornecedor de IA e porta.
- Adicionados testes sem dependências externas para cenários válidos e configurações perigosas.
- Versão móvel/Expo atualizada para `0.26.0`.

## Comandos
Na raiz do repositório:

```bash
npm run preflight
npm run test:preflight
npm run preflight:production
```

O comando de produção usa as variáveis de ambiente do processo atual; não lê ficheiros `.env` automaticamente. Configura as variáveis no ambiente de staging/produção e executa o comando nesse contexto. Não imprimas nem partilhes segredos nos logs.

## Limitações
Estas verificações são um filtro inicial, não uma auditoria de segurança. Não comprovam conectividade à base de dados, migrações, autenticação ponta a ponta, TLS real, permissões do fornecedor, builds móveis nem conformidade legal. Não uses credenciais reais no repositório. Antes de produção, são necessários testes em staging, revisão de permissões/backup/monitorização e validação por responsáveis técnicos.
