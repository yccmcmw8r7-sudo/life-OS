# LIFE OS v0.27 — contratos de segurança de conta

## O que mudou
- Adicionado `scripts/verify-account-contract.mjs`, verificador sem dependências externas para os limites de segurança dos endpoints de conta.
- O contrato verifica a proteção por `AuthGuard`, cabeçalhos contra cache da exportação, seleção explícita dos campos de perfil, ausência de credenciais, escopo por utilizador nas sete coleções exportadas, frase de confirmação, validação do email e palavra-passe atual, e eliminação apenas do ID autenticado.
- Adicionados sete testes de regressão, incluindo mutações negativas que simulam remoções de controlos de segurança.
- Adicionados os comandos `npm run verify:account-contract` e `npm run test:contracts`.
- Versões móvel e Expo alinhadas em `0.27.0`.

## Validação
Executar na raiz:

```bash
npm run test:contracts
```

Os testes de contrato são verificações estáticas do código-fonte: ajudam a detetar regressões evidentes, mas não executam os endpoints HTTP nem provam o comportamento real do NestJS, Prisma ou PostgreSQL. Continuam necessários testes de controller, integração numa base PostgreSQL descartável, build móvel e revisão de segurança antes de produção.
